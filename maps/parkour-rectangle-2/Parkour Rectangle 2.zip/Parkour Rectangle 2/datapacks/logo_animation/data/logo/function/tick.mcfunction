#add score
scoreboard players add #logo logoanimation 1
execute if score #logo logoanimation matches 40.. run scoreboard players set #logo logoanimation 1

#Frames
execute if score #logo logoanimation matches 1 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":111},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 2 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":112},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 3 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":113},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 4 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":114},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 5 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":115},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 6 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":116},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 7 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":117},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 8 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":118},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 9 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":119},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 10 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":120},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 11 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":121},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 12 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":122},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 13 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":123},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 14 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":124},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 15 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":125},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 16 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":126},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 17 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":127},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 18 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":128},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 19 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":129},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 20 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":130},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 21 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":131},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 22 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":132},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 23 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":133},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 24 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":134},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 25 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":135},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 26 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":136},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 27 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":137},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 28 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":138},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 29 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":139},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 30 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":140},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 31 run data merge entity 13ac1271-f3f2-4c04-bea0-3feb051e8b87 {Item:{components:{"minecraft:map_id":111},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}