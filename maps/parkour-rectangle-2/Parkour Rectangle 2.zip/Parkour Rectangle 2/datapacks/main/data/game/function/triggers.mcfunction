#Reset
scoreboard players enable @a reset
execute as @a[scores={reset=1..}] at @s run function game:triggers/reset
execute as @a[scores={reset=1..}] at @s run scoreboard players reset @s reset

#Restart
scoreboard players enable @a restart
execute as @a[scores={restart=1..}] at @s run function game:triggers/restart
execute as @a[scores={restart=1..}] at @s run scoreboard players reset @s restart