#previous map
execute if block -56 84 -20 minecraft:oak_button[powered=true,facing=west,face=wall] run scoreboard players remove #more_maps more_maps 1
execute if block -56 84 -20 minecraft:oak_button[powered=true,facing=west,face=wall] run setblock -56 84 -20 minecraft:oak_button[powered=false,facing=west,face=wall]

#next map
execute if block -56 84 -16 minecraft:oak_button[powered=true,facing=west,face=wall] run scoreboard players add #more_maps more_maps 1
execute if block -56 84 -16 minecraft:oak_button[powered=true,facing=west,face=wall] run setblock -56 84 -16 minecraft:oak_button[powered=false,facing=west,face=wall]

#start and end limit
execute if score #more_maps more_maps matches 0 run scoreboard players set #more_maps more_maps 2
execute if score #more_maps more_maps matches 3 run scoreboard players set #more_maps more_maps 1

#Parkour Rectangle
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map1,limit=1] {Item:{components:{"minecraft:map_id":150},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map2,limit=1] {Item:{components:{"minecraft:map_id":151},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map3,limit=1] {Item:{components:{"minecraft:map_id":152},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map4,limit=1] {Item:{components:{"minecraft:map_id":153},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map5,limit=1] {Item:{components:{"minecraft:map_id":154},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map6,limit=1] {Item:{components:{"minecraft:map_id":155},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map7,limit=1] {Item:{components:{"minecraft:map_id":156},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map8,limit=1] {Item:{components:{"minecraft:map_id":157},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map9,limit=1] {Item:{components:{"minecraft:map_id":158},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge block -56 86 -18 {front_text:{messages:[[{"text":"Parkour","bold":true,"color":"white"}],[{"text":"Rectangle","bold":true,"color":"white"}],"",[{"text":"[LINK]","bold":true,"color":"blue","click_event":{"action":"run_command","command":"/tellraw @s [\"\",{\"text\":\"Parkour Rectangle: \",\"bold\":true},{\"text\":\"[LINK]\",\"bold\":true,\"color\":\"blue\",\"click_event\":{\"action\":\"open_url\",\"url\":\"https://ziya8637maps.github.io/maps/parkour-rectangle/\"},\"hover_event\":{\"action\":\"show_text\",\"value\":\"https://ziya8637maps.github.io/maps/parkour-rectangle/\"}}]"}}]]}}

#Parkour Rectangle 2
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map1,limit=1] {Item:{components:{"minecraft:map_id":141},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map2,limit=1] {Item:{components:{"minecraft:map_id":142},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map3,limit=1] {Item:{components:{"minecraft:map_id":143},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map4,limit=1] {Item:{components:{"minecraft:map_id":144},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map5,limit=1] {Item:{components:{"minecraft:map_id":145},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map6,limit=1] {Item:{components:{"minecraft:map_id":146},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map7,limit=1] {Item:{components:{"minecraft:map_id":147},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map8,limit=1] {Item:{components:{"minecraft:map_id":148},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map9,limit=1] {Item:{components:{"minecraft:map_id":149},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge block -56 86 -18 {front_text:{messages:[[{"text":"Parkour","bold":true,"color":"white"}],["",{"text":"Rectangle ","bold":true,"color":"white"},{"text":"3","bold":true,"color":"red"}],"",[{"text":"[LINK]","bold":true,"color":"blue","click_event":{"action":"run_command","command":"/tellraw @s [\"\",{\"text\":\"Parkour Rectangle \",\"bold\":true},{\"text\":\"3\",\"bold\":true,\"color\":\"red\"},{\"text\":\": \",\"bold\":true},{\"text\":\"[LINK]\",\"bold\":true,\"color\":\"blue\",\"click_event\":{\"action\":\"open_url\",\"url\":\"https://ziya8637maps.github.io/maps/parkour-rectangle-3/\"},\"hover_event\":{\"action\":\"show_text\",\"value\":\"https://ziya8637maps.github.io/maps/parkour-rectangle-3/\"}}]"}}]]}}