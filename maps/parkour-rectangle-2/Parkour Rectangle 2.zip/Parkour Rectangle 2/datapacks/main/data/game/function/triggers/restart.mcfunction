gamemode adventure
spawnpoint @s -71 83 -21 0
function timer:reset
scoreboard players reset @s afk
scoreboard players reset @s time_display
scoreboard players reset @s level
scoreboard players reset @s level_display
tag @s remove InParkour
title @s clear
tp @s -71 83 -18 0 0