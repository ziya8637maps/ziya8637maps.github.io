scoreboard players reset @s level
scoreboard players reset @s level_display
scoreboard players reset @s afk
function timer:reset
tp @s -71 83 -21 0 0
gamemode adventure