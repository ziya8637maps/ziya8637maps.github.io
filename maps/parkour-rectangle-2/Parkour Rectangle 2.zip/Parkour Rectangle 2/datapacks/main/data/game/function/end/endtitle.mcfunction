title @s[scores={end=1}] times 0 220 20
playsound minecraft:entity.lightning_bolt.thunder master @s[scores={end=1}] ~ ~ ~ 9999 1

title @s[scores={end=1}] title {"text":"T","color":"yellow"}
title @s[scores={end=3}] title {"text":"Th","color":"yellow"}
title @s[scores={end=5}] title {"text":"The","color":"yellow"}
title @s[scores={end=7}] title {"text":"The ","color":"yellow"}
title @s[scores={end=9}] title {"text":"The E","color":"yellow"}
title @s[scores={end=11}] title {"text":"The En","color":"yellow"}
title @s[scores={end=13}] title {"text":"The End","color":"yellow"}

title @s[scores={end=33}] subtitle "T"
title @s[scores={end=35}] subtitle "Th"
title @s[scores={end=37}] subtitle "Tha"
title @s[scores={end=39}] subtitle "Than"
title @s[scores={end=41}] subtitle "Thank"
title @s[scores={end=43}] subtitle "Thanks"
title @s[scores={end=45}] subtitle "Thanks "
title @s[scores={end=47}] subtitle "Thanks f"
title @s[scores={end=49}] subtitle "Thanks fo"
title @s[scores={end=51}] subtitle "Thanks for"
title @s[scores={end=53}] subtitle "Thanks for "
title @s[scores={end=55}] subtitle "Thanks for p"
title @s[scores={end=57}] subtitle "Thanks for pl"
title @s[scores={end=59}] subtitle "Thanks for pla"
title @s[scores={end=61}] subtitle "Thanks for play"
title @s[scores={end=63}] subtitle "Thanks for playi"
title @s[scores={end=65}] subtitle "Thanks for playin"
title @s[scores={end=67}] subtitle "Thanks for playing"
title @s[scores={end=69}] subtitle "Thanks for playing!"