#1-10 Levels
execute as @a[x=-150,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 1
execute as @a[x=-134,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 2
execute as @a[x=-118,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 3
execute as @a[x=-102,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 4
execute as @a[x=-86,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 5
execute as @a[x=-70,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 6
execute as @a[x=-54,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 7
execute as @a[x=-38,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 8
execute as @a[x=-22,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 9
execute as @a[x=-6,y=9999,z=10,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 10

#11-20 Levels
execute as @a[x=-6,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 11
execute as @a[x=-22,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 12
execute as @a[x=-38,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 13
execute as @a[x=-54,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 14
execute as @a[x=-70,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 15
execute as @a[x=-86,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 16
execute as @a[x=-102,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 17
execute as @a[x=-118,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 18
execute as @a[x=-134,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 19
execute as @a[x=-150,y=9999,z=26,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 20

#21-30 Levels
execute as @a[x=-150,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 21
execute as @a[x=-134,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 22
execute as @a[x=-118,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 23
execute as @a[x=-102,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 24
execute as @a[x=-86,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 25
execute as @a[x=-70,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 26
execute as @a[x=-54,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 27
execute as @a[x=-38,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 28
execute as @a[x=-22,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 29
execute as @a[x=-6,y=9999,z=42,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 30

#31-40 Levels
execute as @a[x=-6,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 31
execute as @a[x=-22,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 32
execute as @a[x=-38,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 33
execute as @a[x=-54,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 34
execute as @a[x=-70,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 35
execute as @a[x=-86,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 36
execute as @a[x=-102,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 37
execute as @a[x=-118,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 38
execute as @a[x=-134,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 39
execute as @a[x=-150,y=9999,z=58,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 40

#41-50 Levels
execute as @a[x=-150,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 41
execute as @a[x=-134,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 42
execute as @a[x=-118,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 43
execute as @a[x=-102,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 44
execute as @a[x=-86,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 45
execute as @a[x=-70,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 46
execute as @a[x=-54,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 47
execute as @a[x=-38,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 48
execute as @a[x=-22,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 49
execute as @a[x=-6,y=9999,z=74,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 50

#51-60 Levels
execute as @a[x=-6,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 51
execute as @a[x=-22,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 52
execute as @a[x=-38,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 53
execute as @a[x=-54,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 54
execute as @a[x=-70,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 55
execute as @a[x=-86,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 56
execute as @a[x=-102,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 57
execute as @a[x=-118,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 58
execute as @a[x=-134,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 59
execute as @a[x=-150,y=9999,z=90,dx=14,dy=-100000,dz=14] at @s run scoreboard players set @s level 60