#Create Scoreboard Objectives

#Level display
scoreboard objectives add level dummy {"text":"Level","color":"yellow","bold":true}
scoreboard objectives add level_display dummy {"text":"Level","color":"yellow","bold":true}
scoreboard objectives setdisplay list level_display
#----------------------------------------

#start and end
scoreboard objectives add intro dummy
scoreboard objectives add end dummy
#--------------------------------------

#triggers
scoreboard objectives add reset trigger {"text": "Reset","color": "yellow","bold": true}
scoreboard objectives add restart trigger {"text": "Restart","color": "yellow","bold": true}
#--------------------------------------


#Button#1
scoreboard objectives add buttons1 dummy
scoreboard objectives add dooropens dummy
#--------------------------------------

#afk
scoreboard objectives add afk dummy

scoreboard objectives add pos_x dummy
scoreboard objectives add pos_y dummy
scoreboard objectives add pos_z dummy
scoreboard objectives add pos_rot dummy

scoreboard objectives add pos_x2 dummy
scoreboard objectives add pos_y2 dummy
scoreboard objectives add pos_z2 dummy
scoreboard objectives add pos_rot2 dummy

scoreboard objectives add tick_switch dummy

team add afk
team modify afk color gray
team modify afk collisionRule never

team add main
team modify main collisionRule never
#-----------------------------------------

#Temp
#/scoreboard players set #is_server temper 1
scoreboard objectives add temper dummy
#-----------------------------------------

#reset objectives
scoreboard players reset @a pos_x2
scoreboard players reset @a pos_y2
scoreboard players reset @a pos_z2
scoreboard players reset @a pos_rot2

scoreboard players reset @a pos_x
scoreboard players reset @a pos_y
scoreboard players reset @a pos_z
scoreboard players reset @a pos_rot

scoreboard players reset @a afk
#------------------------------------------