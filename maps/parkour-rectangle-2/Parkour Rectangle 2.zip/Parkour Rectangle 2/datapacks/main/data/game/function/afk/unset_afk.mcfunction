tag @s remove afk

execute unless score #is_server temp matches 1 run tellraw @a[distance=0.1..] [{"selector":"@s","color":"gray"},{"text":" is no longer AFK","color":"gray"}]
execute unless score #is_server temp matches 1 run team join main @s

tellraw @s {"text":"You are no longer AFK.","color":"gray"}

tag @s add ingame