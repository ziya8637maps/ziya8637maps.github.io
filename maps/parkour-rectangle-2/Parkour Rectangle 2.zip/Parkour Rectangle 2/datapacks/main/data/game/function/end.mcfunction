scoreboard players operation @s rank_timer = @s timer
scoreboard players operation @s pb_hours = @s hours
scoreboard players operation @s pb_minutes = @s minutes
scoreboard players operation @s pb_seconds = @s seconds
tag @s add finished
tag @s add end
tag @s remove InParkour
team join finished @s
function timer:stop