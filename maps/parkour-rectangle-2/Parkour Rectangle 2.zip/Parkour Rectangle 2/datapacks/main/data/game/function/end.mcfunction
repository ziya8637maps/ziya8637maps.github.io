scoreboard players operation @s rank_timer = @s timer
scoreboard players operation @s pb_hours = @s hours
scoreboard players operation @s pb_minutes = @s minutes
scoreboard players operation @s pb_seconds = @s seconds
tellraw @s [{"text":"You","color":"#39e271"},{"text":" completed the parkour map in ","color":"#39e271"},{"score":{"objective":"time_display","name":"@s"}},{"text":" seconds!"}]
execute unless score #is_server temper matches 1 run tellraw @a[distance=0.1..] [{"selector":"@s","color":"#39e271"},{"text":" completed the parkour map in ","color":"#39e271"},{"score":{"objective":"time_display","name":"@s"}},{"text":" seconds!"}]
tag @s add finished
tag @s add end
tag @s remove InParkour
team join finished @s
function timer:stop