

#lobby fall (teleport)
execute as @a[x=9,y=-17,z=-91,dx=-160,dy=0,dz=99] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=9,y=-17,z=-91,dx=-160,dy=0,dz=99] at @s if block ~ ~ ~ water run tp @s -71 83 -21 0 0

#Level_2 (teleport)
execute as @a[x=-134,y=-22,z=10,dx=14,dy=0,dz=11] at @s if block ~ ~ ~ lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-134,y=-22,z=10,dx=14,dy=0,dz=11] at @s if block ~ ~ ~ minecraft:lava run tp @s -133.000 -9 24.000

#Level_16 (teleport)
execute as @a[x=-85,y=-26,z=27,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-85,y=-26,z=27,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ lava run tp @s -74 -23 28

#Level_24 (teleport)
execute as @a[x=-101,y=-6,z=55,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-101,y=-6,z=55,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -90 -30 54 135 ~

#Level_25 (teleport)
execute as @a[x=-72,y=-16,z=42,dx=-2,dy=0,dz=3] at @s if block ~ ~ ~ minecraft:lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-72,y=-16,z=42,dx=-2,dy=0,dz=3] at @s if block ~ ~ ~ minecraft:lava run tp @s -78 -9 46 ~ ~

#Level_28 (teleport)
execute as @a[x=-37,y=-31,z=43,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ minecraft:lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-37,y=-31,z=43,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ minecraft:lava run tp @s -36 -28 54

#Teleport to Level_30 (teleport)
execute as @a[x=-9,y=-3,z=43,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-9,y=-3,z=43,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -5 -33 43 -45 ~

#Teleport to Level 43 (teleport)
execute as @a[x=-130,y=9,z=84,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-130,y=9,z=84,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -118 -33 78 -67.5 ~

#Level_35 (teleport)
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12] at @s if block ~ ~ ~ water run tp @s -58 -25 70 90 0


#Clear_levitation
effect clear @a minecraft:levitation

#Level_2_levitation
execute as @a[x=-120,y=-20,z=10,dy=12] at @s run effect give @s minecraft:levitation 1 5 true

#Level_3_levitation
execute as @a[x=-118,y=-11,z=24,dy=3] at @s run effect give @s minecraft:levitation 1 3 true
execute as @a[x=-105,y=-24,z=23,dy=16] at @s run effect give @s minecraft:levitation 1 5 true

#Level_4_levitation
execute as @a[x=-89,y=-33,z=11,dy=25] at @s run effect give @s minecraft:levitation 1 5 true

#Level_7_levitation
execute as @a[x=-53,y=-24,z=23,dy=18] at @s run effect give @s minecraft:levitation 1 5 true

#Level_10_levitation
execute as @a[x=7,y=-28,z=11,dy=20] at @s run effect give @s minecraft:levitation 1 5 true

#Level_11_levitation
execute as @a[x=-6,y=-14,z=40,dy=5] at @s run effect give @s minecraft:levitation 1 1 true

#Level_12_levitation
execute as @a[x=-8,y=-10,z=39,dy=4] at @s run effect give @s minecraft:levitation 1 1 true

#Level_13_levitation
execute as @a[x=-24,y=-10,z=40,dy=4] at @s run effect give @s minecraft:levitation 1 1 true

#Level_15_levitation
execute as @a[x=-56,y=-9,z=28,dy=4] at @s run effect give @s minecraft:levitation 1 1 true
execute as @a[x=-57,y=-20,z=39,dy=15] at @s run effect give @s minecraft:levitation 1 5 true

#Level_16_levitation
execute as @a[x=-85,y=-21,z=27,dy=16] at @s run effect give @s minecraft:levitation 1 5 true

#Level_20_levitation
execute as @a[x=-149,y=-21,z=27,dy=18] at @s run effect give @s minecraft:levitation 1 5 true

#Level_22_levitation
execute as @a[x=-134,y=-12,z=46,dy=2] at @s run effect give @s minecraft:levitation 1 1 true
execute as @a[x=-133,y=-25,z=43,dy=20] at @s run effect give @s minecraft:levitation 1 5 true

#Level_24_levitation
execute as @a[x=-101,y=-30,z=43,dy=5] at @s run effect give @s minecraft:levitation 1 1 true
execute as @a[x=-89,y=-24,z=55,dy=20] at @s run effect give @s minecraft:levitation 1 5 true

#Level_27_levitation
execute as @a[x=-53,y=-20,z=43,dy=16] at @s run effect give @s minecraft:levitation 1 5 true

#Level_28_levitation
execute as @a[x=-25,y=-26,z=55,dy=22] at @s run effect give @s minecraft:levitation 1 5 true

#Level_29_levitation
execute as @a[x=-9,y=-14,z=56,dy=11] at @s run effect give @s minecraft:levitation 1 5 true

#Level_35_levitation
execute as @a[x=-57,y=-25,z=59,dy=20] at @s run effect give @s minecraft:levitation 1 5 true

#Level_42_levitation
execute as @a[x=-133,y=-21,z=75,dy=17] at @s run effect give @s minecraft:levitation 1 5 true

#Level_49_levitation
execute as @a[x=-21,y=-20,z=75,dy=16] at @s run effect give @s minecraft:levitation 1 5 true

#Level_55_levitation
execute as @a[x=-57,y=-22,z=103,dy=17] at @s run effect give @s minecraft:levitation 1 5 true

#Level_56_57_levitation
execute as @a[x=-101,y=-21,z=103,dy=16] at @s run effect give @s minecraft:levitation 1 5 true


#fire tick
effect give @a minecraft:fire_resistance infinite 255 true
execute as @a at @s if block ~ ~ ~ minecraft:fire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:lava run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:soul_campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~-1 ~ minecraft:magma_block run effect clear @s minecraft:fire_resistance

#effects
effect give @a minecraft:saturation infinite 255 true
effect give @a minecraft:resistance infinite 255 true

#portals
execute as @a[x=-72,y=83,z=-16,dy=2,dx=2,dz=0] at @s if block ~ ~ ~ end_gateway run function game:portals/start
execute as @a[x=-220,y=-9,z=157,dx=0,dy=2,dz=2] at @s if block ~ ~ ~ minecraft:end_gateway run function game:portals/lobby
execute as @a[x=-202,y=-10,z=152,dz=19,dy=24,dx=-18,tag=ingame] at @s run function game:end

function game:levels/tick
function game:intro/tick
function game:end/tick
function game:triggers
execute as @a[tag=InParkour] at @s run function game:afk/tick