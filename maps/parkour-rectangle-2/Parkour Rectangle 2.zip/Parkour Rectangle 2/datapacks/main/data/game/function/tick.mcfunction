function game:more_maps/tick

#lobby fall (teleport)
execute as @a[x=9,y=-17,z=-91,dx=-160,dy=0,dz=99,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=9,y=-17,z=-91,dx=-160,dy=0,dz=99,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -71 83 -21 0 0

#Level 8 (teleport)
execute as @a[x=-27,y=-10,z=14,dy=2,gamemode=adventure] at @s if block ~ ~ ~ lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-27,y=-10,z=14,dy=2,gamemode=adventure] at @s if block ~ ~ ~ lava run tp @s -37.0 -7 11 -90 ~

#Level_10 (teleport)
execute as @a[x=-3,y=-15,z=21,dy=0,dx=-1,dz=1,gamemode=adventure] at @s if block ~ ~ ~ water run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-3,y=-15,z=21,dy=0,dx=-1,dz=1,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -5 -14.06250 17 -90 ~
#- villager
execute as @e[type=villager,distance=..2,x=-3,y=-15,z=21,dy=0,dx=-1,dz=1,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -5 -14.06250 17 -90 ~

#Level_13 (teleport)
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ water run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -25 -5 39 180 ~
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -25 -5 39 180 ~
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-38,y=-10,z=26,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run tp @s -25 -5 39 180 ~

#Level_22-23
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ water run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -134 -4 42 -22.5 ~
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run tp @s -134 -4 42 -22.5 ~
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-104,y=-12,z=56,dy=0,dx=-30,dz=-14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -134 -4 42 -22.5 ~

#Level_25 (teleport)
execute as @a[x=-72,y=-16,z=42,dx=-13,dy=0,dz=13,gamemode=adventure] at @s if block ~ ~ ~ lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-72,y=-16,z=42,dx=-13,dy=0,dz=13,gamemode=adventure] at @s if block ~ ~ ~ lava run tp @s -78 -9 46 ~ ~

#Level_26 (teleport)
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ water run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -69 -4.125 43 -62.5 ~
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run tp @s -69 -4.125 43 -62.5 ~
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -69 -4.125 43 -62.5 ~
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ small_dripleaf run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ small_dripleaf run tp @s -69 -4.125 43 -62.5 ~
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ big_dripleaf_stem run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-56,y=-8,z=42,dy=-2,dz=14,dx=-14,gamemode=adventure] at @s if block ~ ~ ~ big_dripleaf_stem run tp @s -69 -4.125 43 -62.5 ~

#Level_28 (teleport)
execute as @a[x=-37,y=-31,z=43,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ minecraft:lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-37,y=-31,z=43,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ minecraft:lava run tp @s -36 -28 54

#Teleport to Level_30
execute as @a[x=-9,y=-3,z=43,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-9,y=-3,z=43,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -4 -33 44 -45 ~

#Teleport to Level_42
execute as @a[x=-148,y=-2,z=83,dy=1] at @s if block ~ ~ ~ end_gateway run playsound entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-148,y=-2,z=83,dy=1] at @s if block ~ ~ ~ end_gateway run tp @s -133 -8.06250 85 -90 ~

#Teleport to Level 43
execute as @a[x=-130,y=9,z=84,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-130,y=9,z=84,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -118 -33 78 -67.5 ~

#Level_43 (teleport)
execute as @a[x=-104,y=-20,z=82,dy=2,gamemode=adventure] at @s if block ~ ~ ~ lava run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-104,y=-20,z=82,dy=2,gamemode=adventure] at @s if block ~ ~ ~ lava run tp @s -106 -20 76 16 ~

#Level_44 (teleport)
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ water run playsound entity.player.teleport
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -101 -8 87 180 ~
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound entity.player.teleport
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -101 -8 87 180 ~
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run playsound entity.player.teleport
execute as @a[x=-102,y=-13,z=74,dy=0,dx=14,dz=14,gamemode=adventure] at @s if block ~ ~ ~ tall_seagrass run tp @s -101 -8 87 180 ~

#Level_35 (teleport)
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -58 -25 70 90 0
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-69,y=-28,z=59,dx=12,dy=0,dz=12,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -58 -25 70 90 0


#Clear_levitation
effect clear @a minecraft:levitation

#Level_11_levitation
execute as @a[x=-6,y=-14,z=40,dy=5] at @s run effect give @s minecraft:levitation 1 1 true

#Level_12_levitation
execute as @a[x=-8,y=-10,z=39,dy=4] at @s run effect give @s minecraft:levitation 1 1 true

#Level_28_levitation
execute as @a[x=-25,y=-26,z=55,dy=22] at @s run effect give @s minecraft:levitation 1 5 true

#Level_29_levitation
execute as @a[x=-9,y=-14,z=56,dy=11] at @s run effect give @s minecraft:levitation 1 5 true

#Level_35_levitation
execute as @a[x=-57,y=-25,z=59,dy=20] at @s run effect give @s minecraft:levitation 1 5 true

#Level_42_levitation
execute as @a[x=-133,y=-21,z=75,dy=17] at @s run effect give @s minecraft:levitation 1 5 true


#fire tick
effect give @a minecraft:fire_resistance infinite 255 true
execute as @a at @s if block ~ ~ ~ minecraft:fire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:lava run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:soul_campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~-1 ~ minecraft:magma_block run effect clear @s minecraft:fire_resistance

#effects
effect give @a minecraft:saturation infinite 255 true
effect give @a minecraft:resistance infinite 255 true

#portals
execute as @a[x=-72,y=83,z=-16,dy=2,dx=2,dz=0] at @s if block ~ ~ ~ end_gateway run function game:portals/start
execute as @a[x=-220,y=-9,z=157,dx=0,dy=2,dz=2] at @s if block ~ ~ ~ minecraft:end_gateway run function game:portals/lobby
execute as @a[x=-202,y=-10,z=152,dz=19,dy=24,dx=-18,tag=ingame] at @s run function game:end
#-----------------------------------------------------------------------------------------------

function game:levels/tick
function game:intro/tick
function game:end/tick
function game:triggers
execute as @a[tag=InParkour] at @s run function game:afk/tick

#buttons1
#Blue Button
execute as @a at @s if block -14 -8 18 minecraft:stone_button[powered=true] run title @s reset
execute if block -14 -8 18 minecraft:stone_button[powered=true] run scoreboard players add #buttons1 buttons1 1
#execute as @a at @s if block -14 -8 18 minecraft:stone_button[powered=true] run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 100 1
execute if block -14 -8 18 minecraft:stone_button[powered=true] run setblock -8 -11 18 minecraft:redstone_lamp[lit=true]
#execute as @a at @s if block -14 -8 18 minecraft:stone_button[powered=true] run title @s title [{"text":"«","color":"white","bold":false},{"text":"Blue","color":"dark_blue","bold":true},{"text":"» ","color":"white","bold":false},{"text":"button is activated!","color":"white","bold":true}]
execute if block -14 -8 18 minecraft:stone_button[powered=true] run setblock -14 -8 18 minecraft:air destroy

#Red Button
execute as @a at @s if block -14 -8 16 minecraft:stone_button[powered=true] run title @s reset
execute if block -14 -8 16 minecraft:stone_button[powered=true] run scoreboard players add #buttons1 buttons1 1
#execute as @a at @s if block -14 -8 16 minecraft:stone_button[powered=true] run title @s title [{"text":"«","color":"white","bold":false},{"text":"Red","color":"#ff0022","bold":true},{"text":"» ","color":"white","bold":false},{"text":"button is activated!","color":"white","bold":true}]
#execute as @a at @s if block -14 -8 16 minecraft:stone_button[powered=true] run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 100 1
execute if block -14 -8 16 minecraft:stone_button[powered=true] run setblock -8 -11 16 minecraft:redstone_lamp[lit=true]
execute if block -14 -8 16 minecraft:stone_button[powered=true] run setblock -14 -8 16 minecraft:air destroy

#Buttons Activated
execute if score #buttons1 buttons1 matches 2.. run scoreboard players add #buttons1 dooropens 1
execute if score #buttons1 dooropens matches 1 run fill -8 -14 18 -8 -12 16 air destroy
execute if score #buttons1 dooropens matches 1 run playsound entity.generic.explode block @a -8 -13 17 0.5
execute if score #buttons1 dooropens matches 1 run particle explosion -8 -13 17 0.2 0.2 0.2 0 1 normal
execute if score #buttons1 dooropens matches 1 run setblock -8 -11 16 minecraft:redstone_lamp[lit=true]
execute if score #buttons1 dooropens matches 1 run setblock -8 -11 18 minecraft:redstone_lamp[lit=true]
execute if score #buttons1 dooropens matches 201.. run setblock -8 -11 16 minecraft:redstone_lamp[lit=false]
execute if score #buttons1 dooropens matches 201.. run setblock -8 -11 18 minecraft:redstone_lamp[lit=false]
execute if score #buttons1 dooropens matches 201.. run scoreboard players reset #buttons1 buttons1
execute if score #buttons1 dooropens matches 201.. run setblock -14 -8 16 minecraft:stone_button[powered=false,face=floor,facing=south]
execute if score #buttons1 dooropens matches 201.. run setblock -14 -8 18 minecraft:stone_button[powered=false,face=floor,facing=north]
execute as @e[type=villager,distance=..2,x=-7,y=-14,z=18,dy=2,dz=-2,dx=0.500] at @s if score #buttons1 dooropens matches 1.. run tp @s -5 -14.06250 17 ~ ~
execute if score #buttons1 dooropens matches 201.. run fill -8 -14 18 -8 -12 16 cherry_fence
execute if score #buttons1 dooropens matches 201.. run playsound block.lava.extinguish block @a -8 -13 17 0.5
execute if score #buttons1 dooropens matches 201.. run scoreboard players reset #buttons1 dooropens