scoreboard players add @a[tag=intro] intro 1

execute as @a[tag=intro] at @s run effect give @s slow_falling 1 1 true
execute as @a at @s run function game:intro/title