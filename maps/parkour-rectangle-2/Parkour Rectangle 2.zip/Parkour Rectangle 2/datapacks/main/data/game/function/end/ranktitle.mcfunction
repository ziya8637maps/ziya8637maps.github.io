title @s[scores={end=329}] times 0 150 20
title @s[scores={end=329}] title " "

playsound minecraft:block.note_block.hat master @s[scores={end=329}] ~ ~ ~ 9999 2
playsound minecraft:block.note_block.hat master @s[scores={end=331}] ~ ~ ~ 9999 2
playsound minecraft:block.note_block.hat master @s[scores={end=333}] ~ ~ ~ 9999 2
playsound minecraft:block.note_block.hat master @s[scores={end=335}] ~ ~ ~ 9999 2

title @s[scores={end=329}] subtitle "R"
title @s[scores={end=331}] subtitle "Ra"
title @s[scores={end=333}] subtitle "Ran"
title @s[scores={end=335}] subtitle "Rank"
title @s[scores={end=375}] subtitle "Rank"

execute as @s[scores={end=375}] run function timer:ranks/show