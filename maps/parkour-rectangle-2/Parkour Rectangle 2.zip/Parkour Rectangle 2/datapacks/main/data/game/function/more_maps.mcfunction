tellraw @s ""
tellraw @s {"text":"More Maps:","bold":true}

#Parkour Cone
#tellraw @s ["",{"text":"Parkour Cone: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-cone/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-cone/"}}]

#Dimension Cones
#/tellraw @s ["",{"text":"Dimension Cones: ","bold":true},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/dimension-cones/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/dimension-cones/"}}]

#Parkour Layers
#tellraw @s ["",{"text":"Parkour Layers: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-layers/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-layers/"}}]

#Parkour Layers 2
#tellraw @s ["",{"text":"Parkour Layers ","bold":true,"color":"white"},{"text":"2","bold":true,"color":"yellow"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-layers-2/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-layers-2/"}}]

#Parkour Layers 3
#tellraw @s ["",{"text":"Parkour Layers ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-layers-3/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-layers-3/"}}]

#Parkour Rectangle
tellraw @s ["",{"text":"Parkour Rectangle","bold":true},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-rectangle/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-rectangle/"}}]

#Parkour Rectangle 3
#tellraw @s ["",{"text":"Parkour Rectangle ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-rectangle-3/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-rectangle-3/"}}]

#Parkour B
#tellraw @s ["",{"text":"Parkour B","bold":true},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-b/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-b/"}}]

#Parkour C
#tellraw @s ["",{"text":"Parkour C","bold":true},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://ziya8637maps.github.io/maps/parkour-c/"},"hoverEvent":{"action":"show_text","contents":"https://ziya8637maps.github.io/maps/parkour-c/"}}]

tellraw @s ""
