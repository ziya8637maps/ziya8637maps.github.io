gamemode adventure
setworldspawn -71 83 -21 0 0
scoreboard players reset @s afk
function timer:reset
scoreboard players reset @s level
scoreboard players reset @s level_display
scoreboard players reset @s time_display
tag @s remove InParkour
title @s clear
tp @s -71 83 -21 0 0