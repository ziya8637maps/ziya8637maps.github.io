title @s title {"text": "A","color": "red"}
playsound entity.player.levelup master @s ~ ~ ~ 100 0.8