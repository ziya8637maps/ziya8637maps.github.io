#S Rank - 930
execute as @a[scores={rank_timer=0..930}] at @s run function timer:ranks/s

#A Rank - 1200
execute as @a[scores={rank_timer=931..1200}] at @s run function timer:ranks/a

#B Rank - 2700
execute as @a[scores={rank_timer=1201..2700}] at @s run function timer:ranks/b

#C Rank - 5400
execute as @a[scores={rank_timer=2701..5400}] at @s run function timer:ranks/c

#D Rank - 5400+
execute as @a[scores={rank_timer=5401..}] at @s run function timer:ranks/d