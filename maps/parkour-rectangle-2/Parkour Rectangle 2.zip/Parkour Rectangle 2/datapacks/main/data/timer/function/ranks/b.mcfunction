title @s title {"text": "B","color": "green"}
playsound entity.player.levelup master @s ~ ~ ~ 100 0.7