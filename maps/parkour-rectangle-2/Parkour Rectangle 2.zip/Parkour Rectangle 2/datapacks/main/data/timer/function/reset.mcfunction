scoreboard players reset @s timer
scoreboard players reset @s ticks
scoreboard players reset @s seconds
scoreboard players reset @s minutes
scoreboard players reset @s hours

function timer:stop