title @s title {"text": "S","color": "gold"}
playsound entity.player.levelup master @s ~ ~ ~ 100 1