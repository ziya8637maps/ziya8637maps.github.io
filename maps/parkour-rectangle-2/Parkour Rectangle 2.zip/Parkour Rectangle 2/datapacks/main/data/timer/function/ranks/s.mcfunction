title @s title {"text": "S","color": "gold"}
playsound entity.player.levelup master @s ~ ~ ~ 100 1

tellraw @s ["",{"selector":"@s"},{"text":" reached the goal «"},{"text":"[","color":"green"},{"text":"S Rank","bold":true,"color":"yellow"},{"text":"]","color":"green"},{"text":"»"}]