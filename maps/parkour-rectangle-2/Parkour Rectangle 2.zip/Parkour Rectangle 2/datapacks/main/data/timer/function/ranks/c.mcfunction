title @s title {"text": "C","color": "blue"}
playsound entity.player.levelup master @s ~ ~ ~ 100 0.6