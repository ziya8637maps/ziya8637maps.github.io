execute as @a[tag=ingame] at @s run title @s actionbar [{"text":"Time","color":"yellow","bold":true},{"text":": ","color":"white","bold":false},{"score":{"name":"@s","objective":"time_display"},"color":"white","bold":false}]

execute as @a[tag=ingame] run scoreboard players operation @s time_display = @s timer
execute as @a[tag=ingame] run scoreboard players operation @s level_display = @s level

scoreboard players add @a[tag=ingame] ticks 1
scoreboard players add @a[scores={ticks=20..}] timer 1

scoreboard players add @a[scores={ticks=20..}] seconds 1
scoreboard players set @a[scores={ticks=20..}] ticks 0

scoreboard players add @a[scores={seconds=60..}] minutes 1
scoreboard players set @a[scores={seconds=60..}] seconds 0

scoreboard players add @a[scores={minutes=60..}] hours 1
scoreboard players set @a[scores={minutes=60..}] minutes 0

function timer:triggers

#finished
execute as @a[x=-135,y=-17,z=89,dx=-500,dy=0,dz=500,tag=finished] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-135,y=-17,z=89,dx=-500,dy=0,dz=500,tag=finished] at @s if block ~ ~ ~ water run tp @s -203 -9 153 45 ~

#ingame_teleport
execute as @a[x=-135,y=-17,z=89,dx=-500,dy=0,dz=500,tag=ingame] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
execute as @a[x=-135,y=-17,z=89,dx=-500,dy=0,dz=500,tag=ingame] at @s if block ~ ~ ~ water run tp @s -155 -9 109 45 ~