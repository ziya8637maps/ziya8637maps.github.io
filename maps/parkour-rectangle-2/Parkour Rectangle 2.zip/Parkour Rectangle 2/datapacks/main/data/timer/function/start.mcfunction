scoreboard players set @s timer 0
scoreboard players set @s ticks 0
scoreboard players set @s seconds 0
scoreboard players set @s minutes 0
scoreboard players set @s hours 0

tag @s add ingame