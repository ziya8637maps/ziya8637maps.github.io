#Ranks
scoreboard players enable @a ranks
execute as @a[scores={ranks=1..}] at @s run tellraw @s ["",{"text":"\n"},{"text":"Rank times:","bold":true,"color":"yellow"},{"text":"\n"},{"text":"S","bold":true,"color":"gold"},{"text":" - 1000 "},{"text":"(16 minutes and 40 seconds)","color":"gray"},{"text":"\n"},{"text":"A","bold":true,"color":"red"},{"text":" - 1200 "},{"text":"(20 minutes)","color":"gray"},{"text":"\n"},{"text":"B","bold":true,"color":"green"},{"text":" - 2700 "},{"text":"(45 minutes)","color":"gray"},{"text":"\n"},{"text":"C","bold":true,"color":"blue"},{"text":" - 5400 "},{"text":"(1 hour 30 minutes)","color":"gray"},{"text":"\n"},{"text":"D","bold":true,"color":"light_purple"},{"text":" - 5400+\n "}]
execute as @a[scores={ranks=1..}] at @s run scoreboard players reset @s ranks

#Reset PB
scoreboard players enable @a reset_pb
execute as @a[scores={reset_pb=1..}] at @s run team leave @s
execute as @a[scores={reset_pb=1..}] at @s run tag @s remove finished
execute as @a[scores={reset_pb=1..}] at @s run tellraw @s {"text": "Your PB been reset.","color": "gray"}
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s reset_pb

#Show PB
scoreboard players enable @a[tag=finished] show_pb
execute as @a[scores={show_pb=1..},tag=finished] at @s run function timer:pb/show_pb
execute as @a[scores={show_pb=1..},tag=finished] at @s run scoreboard players reset @s show_pb

scoreboard players enable @a[tag=!finished] show_pb
execute as @a[scores={show_pb=1..},tag=!finished] at @s run tellraw @s {"text":"No PB Set.","color":"gray"}
execute as @a[scores={show_pb=1..},tag=!finished] at @s run scoreboard players reset @s show_pb