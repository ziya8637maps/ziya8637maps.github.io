title @s title {"text": "D","color": "light_purple"}
playsound entity.player.levelup master @s ~ ~ ~ 100 0.52