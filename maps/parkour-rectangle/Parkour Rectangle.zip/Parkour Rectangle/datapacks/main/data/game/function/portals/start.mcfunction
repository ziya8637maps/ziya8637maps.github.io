team leave @s
scoreboard players reset @s show_pb
tag @s add intro
tag @s add InParkour
function timer:start
scoreboard players reset @s afk
tp @s -93 32 -1