scoreboard players add @a[tag=end] end 1

execute as @a at @s run function game:end/end_title
execute as @a at @s run function game:end/rank_title

execute as @a[scores={end=375..}] at @s run tag @s remove end
execute as @a[scores={end=289}] at @s run function timer:pb/show
execute as @a[scores={end=375..}] at @s run scoreboard players reset @s end