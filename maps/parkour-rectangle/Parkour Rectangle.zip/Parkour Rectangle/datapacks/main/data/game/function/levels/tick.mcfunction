#Level 1
scoreboard players set @s[x=-101,y=-43,z=-2,dx=9,dy=9999,dz=9] level 1

#Level 2
scoreboard players set @s[x=-90,y=-41,z=-2,dx=9,dy=9999,dz=9] level 2

#Level 3
scoreboard players set @s[x=-79,y=-39,z=-2,dx=9,dy=9999,dz=9] level 3

#Level 4
scoreboard players set @s[x=-68,y=-41,z=-2,dx=9,dy=9999,dz=9] level 4

#Level 5
scoreboard players set @s[x=-57,y=-41,z=-2,dx=9,dy=9999,dz=9] level 5

#Level 6
scoreboard players set @s[x=-46,y=-42,z=-2,dx=9,dy=9999,dz=9] level 6

#Level 7
scoreboard players set @s[x=-35,y=-40,z=-2,dx=9,dy=9999,dz=9] level 7

#Level 8
scoreboard players set @s[x=-24,y=-43,z=-2,dx=9,dy=9999,dz=9] level 8

#Level 9
scoreboard players set @s[x=-13,y=-39,z=-2,dx=9,dy=9999,dz=9] level 9

#Level 10
scoreboard players set @s[x=-2,y=-40,z=-2,dx=9,dy=9999,dz=9] level 10

#Level 11
scoreboard players set @s[x=-2,y=-40,z=-13,dx=9,dy=9999,dz=9] level 11

#Level 12
scoreboard players set @s[x=-13,y=-40,z=-13,dx=9,dy=9999,dz=9] level 12

#Level 13
scoreboard players set @s[x=-24,y=-40,z=-13,dx=9,dy=9999,dz=9] level 13

#Level 14
scoreboard players set @s[x=-35,y=-39,z=-13,dx=9,dy=9999,dz=9] level 14

#Level 15
scoreboard players set @s[x=-46,y=-39,z=-13,dx=9,dy=9999,dz=9] level 15

#Level 16
scoreboard players set @s[x=-57,y=-38,z=-13,dx=9,dy=9999,dz=9] level 16

#Level 17
scoreboard players set @s[x=-68,y=-40,z=-13,dx=9,dy=9999,dz=9] level 17

#Level 18
scoreboard players set @s[x=-78,y=-40,z=-13,dx=9,dy=9999,dz=9] level 18

#Level 19
scoreboard players set @s[x=-90,y=-39,z=-13,dx=9,dy=9999,dz=9] level 19

#Level 20
scoreboard players set @s[x=-101,y=-38,z=-13,dx=9,dy=9999,dz=9] level 20

#Level 21
scoreboard players set @s[x=-101,y=-42,z=-24,dx=9,dy=9999,dz=9] level 21

#Level 22
scoreboard players set @s[x=-90,y=-42,z=-24,dx=9,dy=9999,dz=9] level 22

#Level 23
scoreboard players set @s[x=-79,y=-40,z=-24,dx=9,dy=9999,dz=9] level 23

#Level 24
scoreboard players set @s[x=-68,y=-39,z=-24,dx=9,dy=9999,dz=9] level 24

#Level 25
scoreboard players set @s[x=-57,y=-39,z=-24,dx=9,dy=9999,dz=9] level 25

#Level 26
scoreboard players set @s[x=-46,y=-38,z=-24,dx=9,dy=9999,dz=9] level 26

#Level 27
scoreboard players set @s[x=-35,y=-38,z=-24,dx=9,dy=9999,dz=9] level 27

#Level 28
scoreboard players set @s[x=-24,y=-40,z=-24,dx=9,dy=9999,dz=9] level 28

#Level 29
scoreboard players set @s[x=-13,y=-40,z=-24,dx=9,dy=9999,dz=9] level 29

#Level 30
scoreboard players set @s[x=-2,y=-40,z=-24,dx=9,dy=9999,dz=9] level 30

#Level 31
scoreboard players set @s[x=-2,y=-40,z=-35,dx=9,dy=9999,dz=9] level 31

#Level 32
scoreboard players set @s[x=-13,y=-40,z=-35,dx=9,dy=9999,dz=9] level 32

#Level 33
scoreboard players set @s[x=-24,y=-39,z=-35,dx=9,dy=9999,dz=9] level 33

#Level 34
scoreboard players set @s[x=-35,y=-42,z=-35,dx=9,dy=9999,dz=9] level 34

#Level 35
scoreboard players set @s[x=-46,y=-40,z=-35,dx=9,dy=9999,dz=9] level 35

#Level 36
scoreboard players set @s[x=-57,y=-40,z=-35,dx=9,dy=9999,dz=9] level 36

#Level 37
scoreboard players set @s[x=-68,y=-40,z=-35,dx=9,dy=9999,dz=9] level 37

#Level 38
scoreboard players set @s[x=-79,y=-40,z=-35,dx=9,dy=9999,dz=9] level 38

#Level 39
scoreboard players set @s[x=-90,y=-40,z=-35,dx=9,dy=9999,dz=9] level 39

#Level 40
scoreboard players set @s[x=-101,y=-40,z=-35,dx=9,dy=9999,dz=9] level 40

#Level 41
scoreboard players set @s[x=-101,y=-39,z=-46,dx=9,dy=9999,dz=9] level 41

#Level 42
scoreboard players set @s[x=-90,y=-39,z=-46,dx=9,dy=9999,dz=9] level 42

#Level 43
scoreboard players set @s[x=-79,y=-40,z=-46,dx=9,dy=9999,dz=9] level 43

#Level 44
scoreboard players set @s[x=-68,y=-40,z=-46,dx=9,dy=9999,dz=9] level 44

#Level 45
scoreboard players set @s[x=-57,y=-38,z=-46,dx=9,dy=9999,dz=9] level 45

#Level 46
scoreboard players set @s[x=-46,y=-40,z=-46,dx=9,dy=9999,dz=9] level 46

#Level 47
scoreboard players set @s[x=-35,y=-40,z=-46,dx=9,dy=9999,dz=9] level 47

#Level 48
scoreboard players set @s[x=-24,y=-40,z=-46,dx=9,dy=9999,dz=9] level 48

#Level 49
scoreboard players set @s[x=-13,y=-40,z=-46,dx=9,dy=9999,dz=9] level 49

#Level 50
scoreboard players set @s[x=-2,y=-38,z=-46,dx=9,dy=9999,dz=9] level 50

#Level 51
scoreboard players set @s[x=-2,y=-38,z=-57,dx=9,dy=9999,dz=9] level 51

#Level 52
scoreboard players set @s[x=-13,y=-38,z=-57,dx=9,dy=9999,dz=9] level 52

#Level 53
scoreboard players set @s[x=-24,y=-39,z=-57,dx=9,dy=9999,dz=9] level 53

#Level 54
scoreboard players set @s[x=-35,y=-39,z=-57,dx=9,dy=9999,dz=9] level 54

#Level 55
scoreboard players set @s[x=-46,y=-39,z=-57,dx=9,dy=9999,dz=9] level 55

#Level 56
scoreboard players set @s[x=-57,y=-39,z=-57,dx=9,dy=9999,dz=9] level 56

#Level 57
scoreboard players set @s[x=-68,y=-39,z=-57,dx=9,dy=9999,dz=9] level 57

#Level 58
scoreboard players set @s[x=-79,y=-40,z=-57,dx=9,dy=9999,dz=9] level 58

#Level 59
scoreboard players set @s[x=-90,y=-40,z=-57,dx=9,dy=9999,dz=9] level 59

#Level 60
scoreboard players set @s[x=-101,y=-39,z=-57,dx=9,dy=9999,dz=9] level 60