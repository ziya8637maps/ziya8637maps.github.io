execute if block ~ ~ ~ minecraft:lava run effect clear @s minecraft:fire_resistance
execute if block ~ ~ ~ minecraft:fire run effect clear @s minecraft:fire_resistance
execute if block ~ ~-1 ~ minecraft:magma_block run effect clear @s minecraft:fire_resistance