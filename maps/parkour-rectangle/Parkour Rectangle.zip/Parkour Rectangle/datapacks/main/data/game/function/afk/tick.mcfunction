scoreboard players add @s[tag=ingame] afk 1

scoreboard players add @s[tag=ingame] tick_switch 1
scoreboard players set @s[scores={tick_switch=2},tag=ingame] tick_switch 0

#pos1
execute if score @s tick_switch matches 0 run function game:afk/save_pos1

#pos2
execute as @a if score @s tick_switch matches 1 run function game:afk/save_pos2

#compare_positions
function game:afk/positions

#set_afk
execute as @a[scores={afk=600},tag=!afk] at @s run function game:afk/set_afk

#unset_afk
execute as @a[scores={afk=0},tag=afk] at @s run function game:afk/unset_afk