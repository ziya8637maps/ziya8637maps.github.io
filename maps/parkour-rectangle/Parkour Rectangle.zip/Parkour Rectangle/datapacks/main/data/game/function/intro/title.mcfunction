title @s[scores={intro=1}] times 0 150 20

title @s[scores={intro=1}] title "P"
title @s[scores={intro=3}] title "Pa"
title @s[scores={intro=5}] title "Par"
title @s[scores={intro=7}] title "Park"
title @s[scores={intro=9}] title "Parko"
title @s[scores={intro=11}] title "Parkou"
title @s[scores={intro=13}] title "Parkour"
title @s[scores={intro=15}] title "Parkour "
title @s[scores={intro=17}] title "Parkour R"
title @s[scores={intro=19}] title "Parkour Re"
title @s[scores={intro=21}] title "Parkour Rec"
title @s[scores={intro=23}] title "Parkour Rect"
title @s[scores={intro=25}] title "Parkour Recta"
title @s[scores={intro=27}] title "Parkour Rectan"
title @s[scores={intro=29}] title "Parkour Rectang"
title @s[scores={intro=31}] title "Parkour Rectangl"
title @s[scores={intro=33}] title "Parkour Rectangle"
title @s[scores={intro=53..}] title {"text":"Parkour Rectangle","color":"white","bold":true}

tag @s[scores={intro=53..}] remove intro
scoreboard players reset @s[scores={intro=53..}] intro
