execute if block ~ ~ ~ minecraft:air run effect give @s minecraft:fire_resistance infinite 255 true

function game:firetick/no_firetick