tp @s -49 -39 453 180 0
gamemode adventure
scoreboard players reset @s afk