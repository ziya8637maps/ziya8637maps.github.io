execute as @a at @s run function game:levels/tick
execute as @a at @s run function game:teleport/tick
function game:triggers
function game:portals/tick
function game:intro/tick
function game:end/tick
execute as @a[tag=InParkour] at @s run function game:afk/tick

#effects
effect give @a minecraft:saturation infinite 255 true
effect give @a minecraft:resistance infinite 255 true
execute as @a at @s run function game:firetick/tick

#end_air
execute as @a[x=-159,y=-39,z=-101,dx=-23,dy=24,dz=-24,tag=ingame] at @s run function game:end