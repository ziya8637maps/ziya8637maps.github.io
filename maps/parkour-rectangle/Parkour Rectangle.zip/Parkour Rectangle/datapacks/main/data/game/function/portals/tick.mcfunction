#start portal
execute as @a[x=-54,y=-38,z=412,dx=8,dy=7,dz=0] at @s if block ~ ~ ~ minecraft:nether_portal run function game:portals/start

#end portal
execute as @a[x=-175,y=-38,z=-122,dx=2,dy=2,dz=0] at @s if block ~ ~ ~ end_gateway run function game:portals/lobby