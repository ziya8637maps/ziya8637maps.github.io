scoreboard players operation @s pb_seconds = @s seconds
scoreboard players operation @s pb_minutes = @s minutes
scoreboard players operation @s pb_hours = @s hours
scoreboard players operation @s rank_timer = @s timer
title @s clear
tag @s add show_pb
tag @s remove InParkour
tag @s add end
team join end @s
function timer:stop