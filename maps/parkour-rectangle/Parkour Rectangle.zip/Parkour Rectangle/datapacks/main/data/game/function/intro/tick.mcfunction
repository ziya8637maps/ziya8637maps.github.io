scoreboard players add @a[tag=intro] intro 1

execute as @a at @s run function game:intro/title