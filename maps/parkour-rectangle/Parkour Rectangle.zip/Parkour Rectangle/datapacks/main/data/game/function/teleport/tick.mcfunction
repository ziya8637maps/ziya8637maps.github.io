#water teleport
execute if block ~ ~ ~ water run playsound minecraft:entity.enderman.teleport master @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] ~ ~ ~ 9999 1
execute if block ~ ~ ~ water run tp @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] -23 -36 -16

execute if block ~ ~ ~ sea_pickle run playsound minecraft:entity.enderman.teleport master @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] ~ ~ ~ 9999 1
execute if block ~ ~ ~ sea_pickle run tp @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] -23 -36 -16

execute if block ~ ~ ~ seagrass run playsound minecraft:entity.enderman.teleport master @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] ~ ~ ~ 9999 1
execute if block ~ ~ ~ seagrass run tp @s[x=-22,y=-40,z=-17,dx=15,dy=0,dz=2] -23 -36 -16

execute if block ~ ~ ~ water run playsound minecraft:entity.enderman.teleport master @s[x=-203,y=-41,z=-159,dx=100,dy=0,dz=200,tag=ingame] ~ ~ ~ 9999 1
execute if block ~ ~ ~ water run tp @s[x=-203,y=-41,z=-159,dx=100,dy=0,dz=200,tag=ingame] -105.000 -38 -52.000

execute if block ~ ~ ~ water run playsound minecraft:entity.enderman.teleport master @s[x=-203,y=-41,z=-159,dx=100,dy=0,dz=200,tag=show_pb] ~ ~ ~ 9999 1
execute if block ~ ~ ~ water run tp @s[x=-203,y=-41,z=-159,dx=100,dy=0,dz=200,tag=show_pb] -161.814 -38 -105

#lava teleport
execute if block ~ ~ ~ lava run playsound minecraft:entity.enderman.teleport master @s[x=-79,y=-40,z=-24,dx=9,dy=0,dz=9] ~ ~ ~ 9999 1
execute if block ~ ~ ~ lava run tp @s[x=-79,y=-40,z=-24,dx=9,dy=0,dz=9] -78.000 -36 -16.000 ~ ~

execute if block ~ ~ ~ lava run playsound minecraft:entity.enderman.teleport master @s[x=-22,y=-40,z=-21,dx=16,dy=0,dz=2] ~ ~ ~ 9999 1
execute if block ~ ~ ~ lava run tp @s[x=-22,y=-40,z=-21,dx=16,dy=0,dz=2] -5 -36 -20 90 0

execute if block ~ ~ ~ lava run playsound minecraft:entity.enderman.teleport master @s[x=-90,y=-39,z=-57,dx=20,dy=0,dz=9] ~ ~ ~ 9999 1
execute if block ~ ~ ~ lava run tp @s[x=-90,y=-39,z=-57,dx=20,dy=0,dz=9] -70.000 -35 -48.000

#teleport to nether
execute run playsound minecraft:entity.enderman.teleport master @s[x=-5,y=-36,z=-16,dx=0,dy=1,dz=0] ~ ~ ~ 9999 1
execute run tp @s[x=-5,y=-36,z=-16,dx=0,dy=1,dz=0] -5 -36 -20 90 0

#teleport to end
execute run playsound minecraft:entity.enderman.teleport master @s[x=-23,y=-36,z=-20,dx=0,dy=1,dz=0] ~ ~ ~ 9999 1
execute run tp @s[x=-23,y=-36,z=-20,dx=0,dy=1,dz=0] -23 -36 -23 -90 0