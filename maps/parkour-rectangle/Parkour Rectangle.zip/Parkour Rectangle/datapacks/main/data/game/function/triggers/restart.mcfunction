effect clear @s minecraft:fire_resistance
gamemode adventure
tag @s remove InParkour
spawnpoint @s -49 -39 453 180
setworldspawn -49 -39 453 180
function timer:reset
title @s clear
scoreboard players reset @s afk
scoreboard players reset @s time_display
scoreboard players reset @s tick_switch
scoreboard players reset @s level_display
scoreboard players reset @s level
tp @s -50 -39.06250 415 180 0