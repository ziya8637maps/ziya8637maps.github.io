tag @s add afk

execute unless score #is_server temper matches 1 run tellraw @a[distance=0.1..] [{"selector":"@s","color":"gray"},{"text":" is now AFK","color":"gray"}]
execute unless score #is_server temper matches 1 run team join afk @s

tellraw @s {"text":"You are now AFK (time paused).","color":"gray"}

function timer:stop
title @s clear
scoreboard players reset @s level_display
scoreboard players reset @s time_display