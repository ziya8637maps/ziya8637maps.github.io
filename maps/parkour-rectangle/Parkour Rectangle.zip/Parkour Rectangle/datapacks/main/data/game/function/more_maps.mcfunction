tellraw @s ""
tellraw @s {"text":"More Maps:","bold":true,"color":"white"}

#Parkour Cone
#tellraw @s ["",{"text":"Parkour Cone: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-cone/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-cone/"}}]

#Dimension Cones
#/tellraw @s ["",{"text":"Dimension Cones: ","bold":true},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/dimension-cones/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/dimension-cones/"}}]

#Parkour layers
#tellraw @s ["",{"text":"Parkour Layers: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-layers/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-layers/"}}]

#Parkour layers 2
#tellraw @s ["",{"text":"Parkour Layers ","bold":true,"color":"white"},{"text":"2","bold":true,"color":"yellow"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-layers-2/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-layers-2/"}}]

#Parkour layers 3
#tellraw @s ["",{"text":"Parkour Layers ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-layers-3/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-layers-3/"}}]

#Parkour Rectangle 2
tellraw @s ["",{"text":"Parkour Rectangle ","bold":true},{"text":"2","bold":true,"color":"yellow"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-rectangle-2/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-rectangle-2/"}}]

#Parkour Rectangle 3
tellraw @s ["",{"text":"Parkour Rectangle ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-rectangle-3/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-rectangle-3/"}}]

#Parkour B
#tellraw @s ["",{"text":"Parkour B: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-b/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-b/"}}]

#Parkour C
#tellraw @s ["",{"text":"Parkour C: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","click_event":{"action":"open_url","url":"https://ziya8637maps.github.io/maps/parkour-c/"},"hover_event":{"action":"show_text","value":"https://ziya8637maps.github.io/maps/parkour-c/"}}]

tellraw @s ""