tellraw @s ""
tellraw @s {"text":"More Maps:","bold":true,"color":"white"}

#Parkour Cone
#tellraw @s ["",{"text":"Parkour Cone: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-cone/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-cone/"}}]

#Dimension Cones
#/tellraw @s ["",{"text":"Dimension Cones: ","bold":true},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/dimension-cones/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/dimension-cones/"}}]

#Parkour layers
#tellraw @s ["",{"text":"Parkour Layers: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-layers/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-layers/"}}]

#Parkour layers 2
#tellraw @s ["",{"text":"Parkour Layers ","bold":true,"color":"white"},{"text":"2","bold":true,"color":"yellow"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-layers-2/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-layers-2/"}}]

#Parkour layers 3
#tellraw @s ["",{"text":"Parkour Layers ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-layers-3/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-layers-3/"}}]

#Parkour Rectangle 2
tellraw @s ["",{"text":"Parkour Rectangle ","bold":true},{"text":"2","bold":true,"color":"yellow"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-rectangle-2/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-rectangle-2/"}}]

#Parkour Rectangle 3
#tellraw @s ["",{"text":"Parkour Rectangle ","bold":true},{"text":"3","bold":true,"color":"red"},{"text":": ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-rectangle-3/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-rectangle-3/"}}]

#Parkour B
#tellraw @s ["",{"text":"Parkour B: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-b/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-b/"}}]

#Parkour C
#tellraw @s ["",{"text":"Parkour C: ","bold":true,"color":"white"},{"text":"[LINK]","bold":true,"italic":true,"underlined":true,"color":"blue","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/project/parkour-c/"},"hoverEvent":{"action":"show_text","contents":"https://www.planetminecraft.com/project/parkour-c/"}}]

tellraw @s ""