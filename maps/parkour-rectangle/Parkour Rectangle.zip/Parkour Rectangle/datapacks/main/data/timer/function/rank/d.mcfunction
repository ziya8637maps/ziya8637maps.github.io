playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 0.52
title @s title {"text":"D","color":"light_purple"}