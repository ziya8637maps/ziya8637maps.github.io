#Show_PB
scoreboard players enable @a[tag=show_pb] show_pb
execute as @a[scores={show_pb=1..},tag=show_pb] at @s run function timer:pb/show_pb
execute as @a[scores={show_pb=1..},tag=show_pb] at @s run scoreboard players reset @s show_pb

scoreboard players enable @a[tag=!show_pb] show_pb
execute as @a[scores={show_pb=1..},tag=!show_pb] at @s run tellraw @s {"text":"No PB Set.","color":"gray"}
execute as @a[scores={show_pb=1..},tag=!show_pb] at @s run scoreboard players reset @s show_pb

#Reset_PB
scoreboard players enable @a reset_pb
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s pb_seconds
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s pb_minutes
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s pb_hours
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s level_display
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s timer
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s time_display
execute as @a[scores={reset_pb=1..}] at @s run tellraw @s {"text":"Your PB been reset.","color":"gray"}
execute as @a[scores={reset_pb=1..}] at @s run team leave @s
execute as @a[scores={reset_pb=1..}] at @s run tag @s remove show_pb
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s show_pb
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s reset_pb

#Ranks
scoreboard players enable @a ranks
execute as @a[scores={ranks=1..}] at @s run tellraw @s ["",{"text":"\n"},{"text":"Rank times:","bold":true,"color":"yellow"},{"text":"\n"},{"text":"S","bold":true,"color":"gold"},{"text":" - 480 ","color":"white"},{"text":"(8 minutes)","color":"gray"},{"text":"\n"},{"text":"A","bold":true,"color":"red"},{"text":" - 660 ","color":"white"},{"text":"(11 minutes)","color":"gray"},{"text":"\n"},{"text":"B","bold":true,"color":"green"},{"text":" - 1320 ","color":"white"},{"text":"(22 minutes)","color":"gray"},{"text":"\n"},{"text":"C","bold":true,"color":"blue"},{"text":" - 2700 ","color":"white"},{"text":"(45 minutes)","color":"gray"},{"text":"\n"},{"text":"D","bold":true,"color":"light_purple"},{"text":" - 2700+","color":"white"},{"text":"\n "}]
execute as @a[scores={ranks=1..}] at @s run scoreboard players reset @s ranks