playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 0.8
title @s title {"text":"A","color":"red"}