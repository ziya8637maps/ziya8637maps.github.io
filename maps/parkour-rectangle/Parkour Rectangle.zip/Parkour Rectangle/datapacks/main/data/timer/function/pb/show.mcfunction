tellraw @s [{"text":"Your final time:","color":"gold","bold":true}]

tellraw @s[scores={pb_hours=2..}] [{"score":{"name":"@s","objective":"pb_hours"},"color":"white"},{"text":" hours","color":"yellow"}]
tellraw @s[scores={pb_hours=1}] [{"score":{"name":"@s","objective":"pb_hours"},"color":"white"},{"text":" hour","color":"yellow"}]

execute unless score @s pb_minutes matches 1 run tellraw @s [{"score":{"name":"@s","objective":"pb_minutes"},"color":"white"},{"text":" minutes","color":"yellow"}]
tellraw @s[scores={pb_minutes=1}] [{"score":{"name":"@s","objective":"pb_minutes"},"color":"white"},{"text":" minute","color":"yellow"}]

execute unless score @s pb_seconds matches 1 run tellraw @s [{"text":"And","color":"yellow"},{"text":" "},{"score":{"name":"@s","objective":"pb_seconds"},"color":"white"},{"text":" seconds!","color":"yellow"}]
tellraw @s[scores={pb_seconds=1}] [{"score":{"name":"@s","objective":"pb_seconds"},"color":"white"},{"text":" seconds!","color":"yellow"}]