playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 0.7
title @s title {"text":"B","color":"green"}