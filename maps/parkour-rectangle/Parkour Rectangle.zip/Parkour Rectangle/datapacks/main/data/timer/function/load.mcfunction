#Create Scoreboard Objectives
scoreboard objectives add timer dummy {"text":"Time","color":"yellow","bold":true}

scoreboard objectives add ticks dummy
scoreboard objectives add seconds dummy
scoreboard objectives add minutes dummy
scoreboard objectives add hours dummy


scoreboard objectives add pb_seconds dummy
scoreboard objectives add pb_minutes dummy
scoreboard objectives add pb_hours dummy
scoreboard objectives add rank_timer dummy


scoreboard objectives add show_pb trigger {"text":"Show PB","color":"yellow","bold":true}
scoreboard objectives add reset_pb trigger {"text":"Reset PB","color":"yellow","bold":true}
scoreboard objectives add ranks trigger {"text":"Ranks","color":"gold","bold":true}

scoreboard objectives add time_display dummy {"text":"Time","color":"yellow","bold":true}
scoreboard objectives add level_display dummy {"text":"Level","color":"yellow","bold":true}
scoreboard objectives setdisplay list level_display