playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 0.6
title @s title {"text":"C","color":"blue"}