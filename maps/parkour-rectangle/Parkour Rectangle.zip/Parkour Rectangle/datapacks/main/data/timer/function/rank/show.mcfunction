#S Rank
execute as @s[scores={rank_timer=0..480}] run function timer:rank/s

#A Rank
execute as @s[scores={rank_timer=481..660}] run function timer:rank/a

#B Rank
execute as @s[scores={rank_timer=661..1320}] run function timer:rank/b

#C Rank
execute as @s[scores={rank_timer=1321..2700}] run function timer:rank/c

#D Rank
execute as @s[scores={rank_timer=2701..}] run function timer:rank/d