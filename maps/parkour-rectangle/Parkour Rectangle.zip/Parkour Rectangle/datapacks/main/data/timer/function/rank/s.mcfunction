playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 1
title @s title {"text":"S","color":"gold"}

tellraw @s ["",{"selector":"@s"},{"text":" reached the goal «"},{"text":"[","color":"green"},{"text":"S Rank","bold":true,"color":"yellow"},{"text":"]","color":"green"},{"text":"»"}]