playsound minecraft:entity.player.levelup master @s ~ ~ ~ 9999 1
title @s title {"text":"S","color":"gold"}