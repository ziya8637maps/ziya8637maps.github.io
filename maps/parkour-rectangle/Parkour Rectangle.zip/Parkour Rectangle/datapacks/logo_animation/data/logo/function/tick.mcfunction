#add score
scoreboard players add #logo logoanimation 1
execute if score #logo logoanimation matches 40.. run scoreboard players set #logo logoanimation 1

#Frames
execute if score #logo logoanimation matches 1 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":159},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 2 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":160},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 3 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":161},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 4 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":162},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 5 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":163},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 6 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":164},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 7 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":165},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 8 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":166},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 9 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":167},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 10 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":168},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 11 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":169},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 12 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":170},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 13 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":171},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 14 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":172},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 15 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":173},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 16 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":174},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 17 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":175},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 18 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":176},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 19 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":177},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 20 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":178},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 21 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":179},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 22 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":180},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 23 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":181},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 24 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":182},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 25 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":183},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 26 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":184},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 27 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":185},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 28 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":186},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 29 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":187},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 30 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":188},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}
execute if score #logo logoanimation matches 31 run data merge entity f33c4940-32b2-4b0b-aba7-077b9eae17c9 {Item:{components:{"minecraft:map_id":159},count:1,id:"minecraft:filled_map"},Fixed:1b,Silent:1b,Invisible:1b}