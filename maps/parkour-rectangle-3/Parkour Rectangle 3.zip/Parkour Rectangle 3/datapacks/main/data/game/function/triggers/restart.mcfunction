gamemode adventure
setworldspawn -98 137 168 180
spawnpoint @s -98 137 168 180
function timer:reset
scoreboard players reset @s afk
scoreboard players reset @s time_display
scoreboard players reset @s level
scoreboard players reset @s level_display
tag @s remove InParkour
title @s clear
tp @s -98 136.9375 165 180 0