function game:snakes/tick
function game:teleport_and_levitation_in_level
function game:portals/tick
function game:intro/tick
function game:end/tick
function game:levels/tick
function game:triggers
function game:open_doors_and_trapdoors
function game:more_maps/tick
execute as @a[tag=InParkour] at @s run function game:afk/tick

#effects
effect give @a saturation 9999 255 true

#cardriving
function game:cardriving/tick
fill -162 -60 95 -162 -56 99 minecraft:black_concrete
fill -204 -60 95 -204 -56 99 minecraft:black_concrete

#fire tick
effect give @a minecraft:fire_resistance infinite 255 true
execute as @a at @s if block ~ ~ ~ minecraft:fire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:lava run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:soul_campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~-1 ~ minecraft:magma_block run effect clear @s minecraft:fire_resistance

#end
execute as @a[x=1,y=-43,z=1,dy=14,dx=15,dz=6,tag=ingame] at @s run function game:end
#-----------------------------------------------------------------------------------------------

#Add effects when teleporting players
execute as @a[x=-89,y=65,z=-9,dx=-87,dy=55,dz=-158] at @s run effect give @s minecraft:jump_boost infinite 1 true
execute as @a[x=-89,y=65,z=-9,dx=-87,dy=55,dz=-158] at @s run effect give @s minecraft:slow_falling infinite 1 true
execute as @a[x=-89,y=65,z=-9,dx=-87,dy=55,dz=-158] at @s run effect give @s minecraft:resistance infinite 1 true

#Clear effects when teleporting players
execute as @a[x=-204,y=5,z=9,dz=126,dy=-99,dx=210] at @s run effect clear @s minecraft:resistance
execute as @a[x=-204,y=5,z=9,dz=126,dy=-99,dx=210] at @s run effect clear @s minecraft:slow_falling
execute as @a[x=-204,y=5,z=9,dz=126,dy=-99,dx=210] at @s run effect clear @s minecraft:jump_boost

execute as @a[x=-15,y=5,z=9,dx=125,dy=-99,dz=-125] at @s run effect clear @s minecraft:resistance
execute as @a[x=-15,y=5,z=9,dx=125,dy=-99,dz=-125] at @s run effect clear @s minecraft:slow_falling
execute as @a[x=-15,y=5,z=9,dx=125,dy=-99,dz=-125] at @s run effect clear @s minecraft:jump_boost

execute as @a[x=-85,y=133,z=158,dx=-48,dy=28,dz=48] at @s run effect clear @s minecraft:resistance
execute as @a[x=-85,y=133,z=158,dx=-48,dy=28,dz=48] at @s run effect clear @s minecraft:slow_falling
execute as @a[x=-85,y=133,z=158,dx=-48,dy=28,dz=48] at @s run effect clear @s minecraft:jump_boost