#Level 1-10
execute as @a[x=5,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -12 -17 133 -90
execute as @a[x=-16,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -15 -11 133 90
execute as @a[x=-37,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -37 -28 117 90
execute as @a[x=-58,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -57 -15 125 90
execute as @a[x=-79,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -80 -39 116 90
execute as @a[x=-100,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -100 -13 116 90
execute as @a[x=-121,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -122 -9 133 121
execute as @a[x=-142,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -142 -6 117 90
execute as @a[x=-163,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -164 -7 134 149
execute as @a[x=-184,y=9999,z=134,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -185 -42 129 59

#Level 11-20
execute as @a[x=-184,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -197 -16 112 -90

execute as @a[x=-142,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -159 -22 109 -135
execute as @a[x=-121,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -139 -61 112 -135
execute as @a[x=-100,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -119 -5 94 -45
execute as @a[x=-79,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -97 -59 104 180
execute as @a[x=-58,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -76 -41 112 180
execute as @a[x=-37,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -55 -31 95 -90
execute as @a[x=-16,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -34 -28 95 -90
execute as @a[x=5,y=9999,z=113,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -13 -17 112 -90

#Level 21-30
execute as @a[x=5,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s 4 -9 92 180
execute as @a[x=-16,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -22 -60 78 135
execute as @a[x=-37,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -38 -28 88 145
execute as @a[x=-58,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -58 -15 90 90
execute as @a[x=-79,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -80 -31 90 180
execute as @a[x=-100,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -109 -58 76 90
execute as @a[x=-121,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -123 -22 83 90

execute as @a[x=-163,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -165 -19 90 180
execute as @a[x=-184,y=9999,z=92,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -185 -16 91 135

#Level 31-40
execute as @a[x=-184,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -200 -43 67 -135
execute as @a[x=-163,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -181 -32 53 -90
execute as @a[x=-142,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -160 -23 70 -90
execute as @a[x=-121,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -140 -13 70 -165
execute as @a[x=-100,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -118 -22 61 -90

execute as @a[x=-58,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -74 -17 63 -65
execute as @a[x=-37,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -38 -13 65 90
execute as @a[x=-16,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -33 -13 70 180
execute as @a[x=5,y=9999,z=71,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -12 -13 68 -90

#Level 41-50
execute as @a[x=5,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s 4 -60 49 90
execute as @a[x=-16,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -17 -60 34
execute as @a[x=-37,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -42 -16 38 18
execute as @a[x=-58,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -61 -58 42 90
execute as @a[x=-79,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -82 -60 33 45
execute as @a[x=-100,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -106 -57 33 -90
execute as @a[x=-121,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -125 -61 35 65

execute as @a[x=-163,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -166 -29 47 135
#execute as @a[x=-184,y=9999,z=50,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s 

#Level 51-60
execute as @a[x=-184,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -185 -27 22 45
execute as @a[x=-163,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -180 -18 11 -45
execute as @a[x=-142,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -159 -18 11 0
execute as @a[x=-121,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -138 -20 11 -90
execute as @a[x=-100,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -117 -18 18

execute as @a[x=-58,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -75 -17 18 -180
execute as @a[x=-37,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -55 -17 16 -90

execute as @a[x=5,y=9999,z=29,dx=-19,dz=-19,dy=-100000] at @s run spawnpoint @s -12 -17 14 -22.5