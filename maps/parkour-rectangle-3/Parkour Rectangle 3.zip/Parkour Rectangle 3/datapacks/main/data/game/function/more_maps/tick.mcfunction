#previous map
execute if block -95 138 175 minecraft:oak_button[powered=true,facing=west,face=wall] run scoreboard players remove #more_maps more_maps 1
execute if block -95 138 175 minecraft:oak_button[powered=true,facing=west,face=wall] run setblock -95 138 175 minecraft:oak_button[powered=false,facing=west,face=wall]

#next map
execute if block -95 138 179 minecraft:oak_button[powered=true,facing=west,face=wall] run scoreboard players add #more_maps more_maps 1
execute if block -95 138 179 minecraft:oak_button[powered=true,facing=west,face=wall] run setblock -95 138 179 minecraft:oak_button[powered=false,facing=west,face=wall]

#start and end limit
execute if score #more_maps more_maps matches 0 run scoreboard players set #more_maps more_maps 2
execute if score #more_maps more_maps matches 3 run scoreboard players set #more_maps more_maps 1

#Parkour Rectangle
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map1,limit=1] {Item:{components:{"minecraft:map_id":38},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map2,limit=1] {Item:{components:{"minecraft:map_id":39},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map3,limit=1] {Item:{components:{"minecraft:map_id":40},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map4,limit=1] {Item:{components:{"minecraft:map_id":41},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map5,limit=1] {Item:{components:{"minecraft:map_id":42},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map6,limit=1] {Item:{components:{"minecraft:map_id":43},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map7,limit=1] {Item:{components:{"minecraft:map_id":44},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map8,limit=1] {Item:{components:{"minecraft:map_id":45},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge entity @e[type=minecraft:glow_item_frame,name=map9,limit=1] {Item:{components:{"minecraft:map_id":46},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 1 run data merge block -95 140 177 {front_text:{messages:[[{"text":"Parkour","bold":true,"color":"white"}],[{"text":"Rectangle","bold":true,"color":"white"}],"",[{"text":"[LINK]","bold":true,"color":"blue","click_event":{"action":"run_command","command":"/tellraw @s [\"\",{\"text\":\"Parkour Rectangle: \",\"bold\":true},{\"text\":\"[LINK]\",\"bold\":true,\"color\":\"blue\",\"click_event\":{\"action\":\"open_url\",\"url\":\"https://ziya8637maps.github.io/maps/parkour-rectangle/\"},\"hover_event\":{\"action\":\"show_text\",\"value\":\"https://ziya8637maps.github.io/maps/parkour-rectangle/\"}}]"}}]]}}

#Parkour Rectangle 2
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map1,limit=1] {Item:{components:{"minecraft:map_id":47},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map2,limit=1] {Item:{components:{"minecraft:map_id":48},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map3,limit=1] {Item:{components:{"minecraft:map_id":49},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map4,limit=1] {Item:{components:{"minecraft:map_id":50},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map5,limit=1] {Item:{components:{"minecraft:map_id":51},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map6,limit=1] {Item:{components:{"minecraft:map_id":52},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map7,limit=1] {Item:{components:{"minecraft:map_id":53},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map8,limit=1] {Item:{components:{"minecraft:map_id":54},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge entity @e[type=minecraft:glow_item_frame,name=map9,limit=1] {Item:{components:{"minecraft:map_id":55},count:1,id:"minecraft:filled_map"},Silent:1b,Fixed:1b}
execute if score #more_maps more_maps matches 2 run data merge block -95 140 177 {front_text:{messages:[[{"text":"Parkour","bold":true,"color":"white"}],["",{"text":"Rectangle ","bold":true,"color":"white"},{"text":"2","bold":true,"color":"yellow"}],"",[{"text":"[LINK]","bold":true,"color":"blue","click_event":{"action":"run_command","command":"/tellraw @s [\"\",{\"text\":\"Parkour Rectangle \",\"bold\":true},{\"text\":\"2\",\"bold\":true,\"color\":\"yellow\"},{\"text\":\": \",\"bold\":true},{\"text\":\"[LINK]\",\"bold\":true,\"color\":\"blue\",\"click_event\":{\"action\":\"open_url\",\"url\":\"https://ziya8637maps.github.io/maps/parkour-rectangle-2/\"},\"hover_event\":{\"action\":\"show_text\",\"value\":\"https://ziya8637maps.github.io/maps/parkour-rectangle-2/\"}}]"}}]]}}