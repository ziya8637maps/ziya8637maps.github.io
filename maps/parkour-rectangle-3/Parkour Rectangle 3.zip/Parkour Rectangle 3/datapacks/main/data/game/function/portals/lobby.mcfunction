scoreboard players reset @s level
spawnpoint @s -98 137 168 180
setworldspawn -98 137 168 180
scoreboard players reset @s level_display
scoreboard players reset @s afk
function timer:reset
tp @s -98 137 168 180 0
gamemode adventure