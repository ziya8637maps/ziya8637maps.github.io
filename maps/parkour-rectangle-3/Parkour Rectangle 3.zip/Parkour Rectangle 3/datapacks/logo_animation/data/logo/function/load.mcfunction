#Create objectives
scoreboard objectives add logoanimation dummy

#set score
scoreboard players set #logo logoanimation 0