#add score
scoreboard players add #logo logoanimation 1
execute if score #logo logoanimation matches 40.. run scoreboard players set #logo logoanimation 1

#Frames
execute if score #logo logoanimation matches 1 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":8},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 2 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":9},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 3 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":10},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 4 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":11},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 5 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":12},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 6 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":13},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 7 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":14},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 8 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":15},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 9 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":16},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 10 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":17},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 11 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":18},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 12 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":19},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 13 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":20},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 14 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":21},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 15 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":22},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 16 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":23},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 17 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":24},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 18 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":25},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 19 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":26},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 20 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":27},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 21 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":28},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 22 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":29},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 23 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":30},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 24 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":31},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 25 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":32},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 26 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":33},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 27 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":34},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 28 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":35},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 29 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":36},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 30 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":37},count:1,id:"minecraft:filled_map"},Fixed:1b}
execute if score #logo logoanimation matches 31 run data merge entity 72af2cee-7b0a-49b9-bd1c-429a11e28699 {Item:{components:{"minecraft:map_id":8},count:1,id:"minecraft:filled_map"},Fixed:1b}