#S Rank - 1560
execute as @a[scores={rank_timer=0..1560}] at @s run function timer:ranks/s

#A Rank - 2250
execute as @a[scores={rank_timer=1561..2250}] at @s run function timer:ranks/a

#B Rank - 4080
execute as @a[scores={rank_timer=2251..4080}] at @s run function timer:ranks/b

#C Rank - 8160
execute as @a[scores={rank_timer=4081..8160}] at @s run function timer:ranks/c

#D Rank - 8160+
execute as @a[scores={rank_timer=8161..}] at @s run function timer:ranks/d