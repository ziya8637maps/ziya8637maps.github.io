#Ranks
scoreboard players enable @a ranks
execute as @a[scores={ranks=1..}] at @s run tellraw @s ["",{"text":"\n"},{"text":"Rank times:","bold":true,"color":"yellow"},{"text":"\n"},{"text":"S","bold":true,"color":"gold"},{"text":" - 1560 "},{"text":"(26 minutes)","color":"gray"},{"text":"\n"},{"text":"A","bold":true,"color":"red"},{"text":" - 2250 "},{"text":"(37 minutes and 30 seconds)","color":"gray"},{"text":"\n"},{"text":"B","bold":true,"color":"green"},{"text":" - 4080 "},{"text":"(1 hour and 8 minutes)","color":"gray"},{"text":"\n"},{"text":"C","bold":true,"color":"blue"},{"text":" - 8160 "},{"text":"(2 hours and 16 minutes)","color":"gray"},{"text":"\n"},{"text":"D","bold":true,"color":"light_purple"},{"text":" - 8160+\n "}]
execute as @a[scores={ranks=1..}] at @s run scoreboard players reset @s ranks

#Reset PB
scoreboard players enable @a reset_pb
execute as @a[scores={reset_pb=1..}] at @s run team leave @s
execute as @a[scores={reset_pb=1..}] at @s run tag @s remove finished
execute as @a[scores={reset_pb=1..}] at @s run tellraw @s [{"text":"PB:","color":"gold","bold":true},{"text":" Your PB been reset.","color":"gray","bold":false}]
execute as @a[scores={reset_pb=1..}] at @s run scoreboard players reset @s reset_pb

#Show PB
scoreboard players enable @a[tag=finished] show_pb
execute as @a[scores={show_pb=1..},tag=finished] at @s run function timer:pb/show_pb
execute as @a[scores={show_pb=1..},tag=finished] at @s run scoreboard players reset @s show_pb

scoreboard players enable @a[tag=!finished] show_pb
execute as @a[scores={show_pb=1..},tag=!finished] at @s run tellraw @s [{"text":"PB:","color":"gold","bold":true},{"text":" No PB Set.","color":"gray","bold":false}]
execute as @a[scores={show_pb=1..},tag=!finished] at @s run scoreboard players reset @s show_pb