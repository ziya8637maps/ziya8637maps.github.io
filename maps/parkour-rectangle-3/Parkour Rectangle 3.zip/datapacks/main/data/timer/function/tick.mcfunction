execute as @a[tag=ingame] at @s run title @s actionbar [{"text":"Nickname","color":"yellow","bold":true},{"text":": ","bold":false,"color":"#ffffff"},{"selector":"@s","color":"white","bold":false},{"text":" | ","color":"white","bold":false},{"text":"Time","color":"yellow","bold":true},{"text":": ","color":"white","bold":false},{"score":{"name":"@s","objective":"time_display"},"color":"white","bold":false}]

execute as @a[tag=ingame] run scoreboard players operation @s time_display = @s timer
execute as @a[tag=ingame] run scoreboard players operation @s level_display = @s level

scoreboard players add @a[tag=ingame] ticks 1
scoreboard players add @a[scores={ticks=20..}] timer 1

scoreboard players add @a[scores={ticks=20..}] seconds 1
scoreboard players set @a[scores={ticks=20..}] ticks 0

scoreboard players add @a[scores={seconds=60..}] minutes 1
scoreboard players set @a[scores={seconds=60..}] seconds 0

scoreboard players add @a[scores={minutes=60..}] hours 1
scoreboard players set @a[scores={minutes=60..}] minutes 0

function timer:triggers