#Snake on Level 4
execute if block -69 -22 132 minecraft:birch_pressure_plate[powered=true] run summon marker ~ ~ ~ {CustomName:[{text:snake1}]}
function game:snakes/snakes/snake1
execute if block -69 -22 132 minecraft:birch_pressure_plate[powered=true] run setblock -69 -22 132 minecraft:air destroy

#Snake on Level 9
execute if block -170 -47 117 jungle_pressure_plate[powered=true] run summon marker ~ ~ ~ {CustomName:[{text:snake2}]}
function game:snakes/snakes/snake2
execute if block -170 -47 117 jungle_pressure_plate[powered=true] run setblock -170 -47 117 air destroy