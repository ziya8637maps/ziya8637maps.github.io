team leave @s
tag @s remove finished
scoreboard players reset @s afk
function timer:start
tag @s add intro
gamemode adventure
playsound minecraft:entity.player.teleport master @s ~ ~ ~ 100 1
tag @s add InParkour
tp @s 4 64 133 90 90