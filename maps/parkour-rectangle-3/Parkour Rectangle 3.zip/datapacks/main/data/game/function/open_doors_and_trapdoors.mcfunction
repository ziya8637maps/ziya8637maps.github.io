#Level2 close door №1
execute as @a[x=-32,y=-31,z=132,dy=1] if block -31 -31 132 minecraft:iron_door[open=true,facing=west,half=lower] run playsound block.iron_door.close block @a -31 -31 132 1
execute as @a[x=-32,y=-31,z=132,dy=1] at @s if block -31 -31 132 minecraft:iron_door[open=true,facing=west,half=lower] run setblock -31 -31 132 minecraft:iron_door[facing=west,half=lower,hinge=right,open=false]
execute as @a[x=-32,y=-31,z=132,dy=1] at @s if block -31 -31 132 minecraft:iron_door[open=true,facing=west,half=lower] run setblock -31 -30 132 minecraft:iron_door[facing=west,half=upper,hinge=right,open=false]
#open door №1
execute as @a[x=-29.99,y=-31,z=132,dy=1] if block -31 -31 132 minecraft:iron_door[open=false,facing=west,half=lower] run playsound block.iron_door.open block @a -31 -31 132 1
execute as @a[x=-29.99,y=-31,z=132,dy=1] at @s if block -31 -31 132 minecraft:iron_door[open=false,facing=west,half=lower] run setblock -31 -31 132 minecraft:iron_door[facing=west,half=lower,hinge=right,open=true]
execute as @a[x=-29.99,y=-31,z=132,dy=1] at @s if block -31 -31 132 minecraft:iron_door[open=false,facing=west,half=lower] run setblock -31 -30 132 minecraft:iron_door[facing=west,half=upper,hinge=right,open=true]

#Level2 open door №2
execute as @a[x=-33,y=-28,z=130,dy=1] if block -33 -28 131 minecraft:iron_door[open=false,half=lower,facing=north] run playsound block.iron_door.open block @a -33 -28 131 1
execute as @a[x=-33,y=-28,z=130,dy=1] at @s if block -33 -28 131 minecraft:iron_door[open=false,half=lower,facing=north] run setblock -33 -28 131 minecraft:iron_door[facing=north,half=lower,hinge=right,open=true]
execute as @a[x=-33,y=-28,z=130,dy=1] at @s if block -33 -28 131 minecraft:iron_door[open=false,half=lower,facing=north] run setblock -33 -27 131 minecraft:iron_door[facing=north,half=upper,hinge=right,open=true]
#close door №2
execute as @a[x=-33,y=-28,z=132,dy=1] if block -33 -28 131 minecraft:iron_door[open=true,half=lower,facing=north] run playsound block.iron_door.close block @a -33 -28 131 1
execute as @a[x=-33,y=-28,z=132,dy=1] at @s if block -33 -28 131 minecraft:iron_door[open=true,half=lower,facing=north] run setblock -33 -28 131 minecraft:iron_door[facing=north,half=lower,hinge=right,open=false]
execute as @a[x=-33,y=-28,z=132,dy=1] at @s if block -33 -28 131 minecraft:iron_door[open=true,half=lower,facing=north] run setblock -33 -27 131 minecraft:iron_door[facing=north,half=upper,hinge=right,open=false]