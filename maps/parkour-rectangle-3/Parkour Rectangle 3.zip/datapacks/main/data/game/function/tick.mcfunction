function game:snakes/tick
function game:teleport_and_levitation_in_level
function game:portals/tick
function game:intro/tick
function game:end/tick
function game:levels/tick
function game:triggers
function game:open_doors_and_trapdoors
execute as @a[tag=InParkour] at @s run function game:afk/tick

#effects
effect give @a saturation 9999 255 true

#cardriving
function game:cardriving/tick
fill -162 -60 95 -162 -56 99 minecraft:black_concrete
fill -204 -60 95 -204 -56 99 minecraft:black_concrete

#fire tick
effect give @a minecraft:fire_resistance infinite 255 true
execute as @a at @s if block ~ ~ ~ minecraft:fire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:lava run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~ ~ minecraft:soul_campfire run effect clear @s minecraft:fire_resistance
execute as @a at @s if block ~ ~-1 ~ minecraft:magma_block run effect clear @s minecraft:fire_resistance

#end
execute as @a[x=1,y=-43,z=1,dy=14,dx=15,dz=6,tag=ingame] at @s run function game:end
#-----------------------------------------------------------------------------------------------