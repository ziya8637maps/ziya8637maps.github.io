title @s[scores={intro=1}] times 0 150 20

title @s[scores={intro=1}] title {"text":"P"}
title @s[scores={intro=4}] title {"text":"Pa"}
title @s[scores={intro=7}] title {"text":"Par"}
title @s[scores={intro=10}] title {"text":"Park"}
title @s[scores={intro=13}] title {"text":"Parko"}
title @s[scores={intro=16}] title {"text":"Parkou"}
title @s[scores={intro=19}] title {"text":"Parkour"}
title @s[scores={intro=22}] title {"text":"Parkour "}

title @s[scores={intro=25}] title {"text":"Parkour R"}
title @s[scores={intro=28}] title {"text":"Parkour Re"}
title @s[scores={intro=31}] title {"text":"Parkour Rec"}
title @s[scores={intro=34}] title {"text":"Parkour Rect"}
title @s[scores={intro=37}] title {"text":"Parkour Recta"}
title @s[scores={intro=40}] title {"text":"Parkour Rectan"}
title @s[scores={intro=43}] title {"text":"Parkour Rectang"}
title @s[scores={intro=46}] title {"text":"Parkour Rectangl"}
title @s[scores={intro=49}] title {"text":"Parkour Rectangle"}

title @s[scores={intro=69}] title [{"text":"Parkour Rectangle "},{"text":"3","color":"red","bold":true}]

playsound minecraft:block.note_block.hat master @s[scores={intro=1}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=4}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=7}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=10}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=13}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=16}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=19}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=22}] ~ ~ ~ 100 1.5

playsound minecraft:block.note_block.hat master @s[scores={intro=25}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=28}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=31}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=34}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=37}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=40}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=43}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=46}] ~ ~ ~ 100 1.5
playsound minecraft:block.note_block.hat master @s[scores={intro=49}] ~ ~ ~ 100 1.5

playsound minecraft:entity.player.levelup master @s[scores={intro=69}] ~ ~ ~ 100 0