execute as @a[x=-99,y=137,z=163,dy=2,dx=2] at @s run function game:portals/start
execute as @a[x=7,y=-43,z=-3,dy=2,dx=2] at @s run function game:portals/lobby