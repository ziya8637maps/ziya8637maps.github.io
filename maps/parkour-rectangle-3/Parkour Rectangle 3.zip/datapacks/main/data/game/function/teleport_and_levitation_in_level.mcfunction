effect clear @a levitation

#LevitationLevel 1
execute as @a at @s run effect give @s[x=4,y=-12,z=116,dy=5] minecraft:levitation 1 2 true

#LevitationLevel 3
execute as @a[x=-50,y=-58,z=119,dy=32] at @s run effect give @s minecraft:levitation 1 10 true

#LevitationLevel 4
execute as @a[x=-67,y=-45,z=125,dy=29] at @s run effect give @s minecraft:levitation 1 10 true

execute as @a[x=-68,y=-53,z=117,dy=14] at @s run fill -69 -53 117 -69 -43 117 barrier
execute as @a[x=-68,y=-53,z=117,dy=14] at @s run fill -68 -53 116 -68 -43 116 barrier
execute as @a[x=-68,y=-53,z=117,dy=14] at @s run fill -67 -53 117 -67 -43 117 minecraft:barrier
execute as @a[x=-68,y=-53,z=117,dy=14] at @s run fill -68 -53 118 -68 -43 118 minecraft:barrier
execute as @a[x=-69,y=-58,z=118,dx=2,dz=-2,dy=2] at @s run fill -69 -53 117 -69 -43 117 air
execute as @a[x=-69,y=-58,z=118,dx=2,dz=-2,dy=2] at @s run fill -68 -53 116 -68 -43 116 air
execute as @a[x=-69,y=-58,z=118,dx=2,dz=-2,dy=2] at @s run fill -67 -53 117 -67 -43 117 minecraft:air
execute as @a[x=-69,y=-58,z=118,dx=2,dz=-2,dy=2] at @s run fill -68 -53 118 -68 -43 118 minecraft:air
execute as @a[x=-68,y=-38,z=117,dy=10] at @s run fill -69 -53 117 -69 -43 117 air
execute as @a[x=-68,y=-38,z=117,dy=10] at @s run fill -68 -53 116 -68 -43 116 air
execute as @a[x=-68,y=-38,z=117,dy=10] at @s run fill -67 -53 117 -67 -43 117 minecraft:air
execute as @a[x=-68,y=-38,z=117,dy=10] at @s run fill -68 -53 118 -68 -43 118 minecraft:air


execute as @a[x=-75,y=-60,z=117,dy=9,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-75,y=-60,z=117,dy=9,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -68 -57.5 117 45 ~
execute as @a[x=-77,y=-61,z=115,dx=19,dz=19,dy=0,gamemode=adventure] at @s if block ~ ~ ~ seagrass run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-77,y=-61,z=115,dx=19,dz=19,dy=0,gamemode=adventure] at @s if block ~ ~ ~ seagrass run tp @s -68 -57.5 117 45 ~
execute as @a[x=-77,y=-61,z=115,dx=19,dz=19,dy=0,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-77,y=-61,z=115,dx=19,dz=19,dy=0,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -68 -57.5 117 45 ~
execute as @a[x=-63,y=-60,z=129,dy=4,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-63,y=-60,z=129,dy=4,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -68 -57.5 117 45 ~

#teleport level 4 to level 5
execute as @a[x=-77,y=-14,z=115,dy=1] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-77,y=-14,z=115,dy=1] at @s if block ~ ~ ~ end_gateway run tp @s -80 -39 116 90 0

#LevitationLevel6
execute as @a[x=-118,y=-52,z=130,dy=2] at @s run effect give @s minecraft:levitation 1 1 true

execute as @a[x=-112,y=-27,z=134,dy=13] at @s run effect give @s minecraft:levitation 1 10 true

#WaterTeleportLevel6
execute as @a[x=-113,y=-56,z=115,dy=4,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-113,y=-56,z=115,dy=4,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run tp @s -101 -12.06250 116 80 0

execute as @a[x=-105,y=-57,z=115,dy=20,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-105,y=-57,z=115,dy=20,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run tp @s -101 -12.06250 116 80 0

execute as @a[x=-100,y=-57,z=120,dy=20,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-100,y=-57,z=120,dy=20,gamemode=adventure] at @s if block ~ ~ ~ minecraft:water run tp @s -101 -12.06250 116 80 0

#LevitationLevel7
execute as @a[x=-138,y=-14,z=117,dy=3] at @s run effect give @s minecraft:levitation 1 1 true

#Teleport level 13 to level 14
execute as @a[x=-144,y=-5,z=111,dy=0] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-144,y=-5,z=111,dy=0] at @s if block ~ ~ ~ end_gateway run tp @s -139 -61 112 -135 ~

#LevitationLevel14
execute as @a[x=-126,y=-59,z=95,dy=2.06250] at @s run effect give @s minecraft:levitation 1 1 true

execute as @a[x=-122,y=-44,z=95,dy=12] at @s run effect give @s minecraft:levitation 1 2 true

#teleport level 14 to level 15
execute as @a[x=-121,y=-22,z=94,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-121,y=-22,z=94,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -119 -5 94 -45 ~

#LevitationLevel21
execute as @a[x=5,y=-44,z=73,dy=7] at @s run effect give @s minecraft:levitation 1 2 true
execute as @a[x=5,y=-32,z=92,dy=4] at @s run effect give @s minecraft:levitation 1 1 true

#Teleport to Level 22
execute as @a[x=5,y=-23,z=73,dy=1] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=5,y=-23,z=73,dy=1] at @s if block ~ ~ ~ end_gateway run tp @s -22 -60 78 135 ~

#Teleport Level 22
execute as @a[x=-24,y=-52,z=73,dy=2,dx=2] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-24,y=-52,z=73,dy=2,dx=2] at @s if block ~ ~ ~ end_gateway run tp @s -32 -37 89.000 -80 ~

#LevitationLevel26
execute as @a[x=-119,y=-43,z=86,dy=24] at @s run effect give @s minecraft:levitation 1 12 true

#Teleport to Level 29
execute as @a[x=-161,y=-15,z=81,dx=3,dz=3] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-161,y=-15,z=81,dx=3,dz=3] at @s if block ~ ~ ~ end_gateway run tp @s -165 -19 90 180 ~

#LevitationLevel34
execute as @a[x=-123,y=-12,z=69,dx=1,dy=5,dz=1] at @s run effect give @s minecraft:levitation 1 1 true

#FailLevel34
execute as @a[x=-126,y=-7,z=57,dy=0,dx=2,gamemode=adventure] at @s if block ~ ~ ~ minecraft:seagrass run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-126,y=-7,z=57,dy=0,dx=2,gamemode=adventure] at @s if block ~ ~ ~ minecraft:seagrass run tp @s -123 -6 68 120 ~

#Teleport Level38
execute as @a[x=-47,y=-15,z=52,dy=2,dx=10,dz=10,gamemode=adventure] at @s if block ~ ~ ~ water run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-47,y=-15,z=52,dy=2,dx=10,dz=10,gamemode=adventure] at @s if block ~ ~ ~ water run tp @s -37.0 -12.9375 66.0 90 ~

execute as @a[x=-47,y=-15,z=52,dy=2,dx=10,dz=10,gamemode=adventure] at @s if block ~ ~ ~ ladder run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-47,y=-15,z=52,dy=2,dx=10,dz=10,gamemode=adventure] at @s if block ~ ~ ~ ladder run tp @s -37.0 -12.9375 66.0 90 ~

#Teleport to Level 38
execute as @a[x=-58,y=-6,z=71,dy=1] at @s if block ~ ~ ~ end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-58,y=-6,z=71,dy=1] at @s if block ~ ~ ~ end_gateway run tp @s -37.0 -12.9375 66.0 90 ~

#LevitationLevel41
execute as @a[x=-14,y=-25,z=50,dy=10] at @s run effect give @s minecraft:levitation 1 5 true

#TeleportPortalLevel41
execute as @a[x=5,y=-47,z=31,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=5,y=-47,z=31,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -12 -26 33 8 ~

#Teleport to Level 41
execute as @a[x=5,y=-9,z=52,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=5,y=-9,z=52,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s 4 -60 49 99 ~

#Teleport to Level 46
execute as @a[x=-86,y=-20,z=31,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-86,y=-20,z=31,dy=1] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -112 -57.0625 35 -59 ~

#Space Teleport
execute as @a[x=-175,y=66,z=-166,dx=85,dy=0,dz=156,gamemode=adventure] at @s run tp @s -116 106 -23 0 ~

#Teleport to Level 47
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run effect clear @s minecraft:slow_falling
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run effect clear @s minecraft:jump_boost
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run effect clear @s minecraft:resistance
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run time set day
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run playsound minecraft:entity.player.teleport block @s ~ ~ ~ 100 1
execute as @a[x=-108,y=106,z=-107,dx=2,dy=3] at @s if block ~ ~ ~ minecraft:end_gateway run tp @s -125 -61 35 68 ~