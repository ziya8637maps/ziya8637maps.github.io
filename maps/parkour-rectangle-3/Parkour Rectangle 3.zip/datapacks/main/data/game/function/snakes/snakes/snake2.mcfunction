execute if entity @e[type=marker,name=snake2] run scoreboard players add #snake2 snakes 1

#Snake fill score 0
execute if score #snake2 snakes matches 1 run setblock -171 -49 117 minecraft:lime_concrete

#Snake fill score 5
execute if score #snake2 snakes matches 6 run setblock -172 -49 117 minecraft:lime_concrete

#Snake fill score 10
execute if score #snake2 snakes matches 11 run setblock -173 -49 117 minecraft:lime_concrete

#Snake fill score 15
execute if score #snake2 snakes matches 16 run fill -171 -49 117 -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 16 run fill -173 -49 117 -174 -49 117 minecraft:lime_concrete

#Snake fill score 20
execute if score #snake2 snakes matches 21 run fill -173 -49 117 -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 21 run fill -174 -49 117 -174 -49 118 minecraft:lime_concrete

#Snake fill score 25
execute if score #snake2 snakes matches 26 run setblock -172 -49 117 minecraft:lime_concrete
execute if score #snake2 snakes matches 26 run fill -173 -49 117 -174 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 26 run fill -174 -49 118 -174 -49 119 minecraft:lime_concrete

#Snake fill score 30
execute if score #snake2 snakes matches 31 run fill -175 -49 119 -174 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 31 run fill -174 -49 118 -174 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 31 run fill -173 -49 117 -172 -49 117 minecraft:lime_concrete

#Snake fill score 35
execute if score #snake2 snakes matches 36 run setblock -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 36 run fill -173 -49 117 -174 -49 117 minecraft:lime_concrete
execute if score #snake2 snakes matches 36 run fill -174 -49 118 -174 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 36 run fill -175 -49 119 -176 -49 119 minecraft:lime_concrete

#Snake fill score 40
execute if score #snake2 snakes matches 41 run fill -173 -49 117 -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 41 run fill -174 -49 117 -174 -49 118 minecraft:lime_concrete
execute if score #snake2 snakes matches 41 run fill -174 -49 119 -175 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 41 run fill -176 -49 119 -176 -49 120 minecraft:lime_concrete

#Snake fill score 45
execute if score #snake2 snakes matches 46 run setblock -172 -49 117 minecraft:lime_concrete
execute if score #snake2 snakes matches 46 run fill -173 -49 117 -174 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 46 run fill -174 -49 118 -174 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 46 run fill -175 -49 119 -176 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 46 run fill -176 -49 120 -176 -49 121 minecraft:lime_concrete

#Snake fill score 50
execute if score #snake2 snakes matches 51 run fill -172 -49 117 -173 -49 117 minecraft:lime_concrete
execute if score #snake2 snakes matches 51 run fill -174 -49 117 -174 -49 118 minecraft:green_concrete
execute if score #snake2 snakes matches 51 run fill -174 -49 119 -175 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 51 run fill -176 -49 119 -176 -49 120 minecraft:green_concrete
execute if score #snake2 snakes matches 51 run fill -176 -49 121 -175 -49 121 minecraft:lime_concrete

#Snake fill score 55
execute if score #snake2 snakes matches 56 run fill -174 -49 121 -175 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 56 run fill -176 -49 121 -176 -49 120 minecraft:green_concrete
execute if score #snake2 snakes matches 56 run fill -176 -49 119 -175 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 56 run fill -174 -49 119 -174 -49 118 minecraft:green_concrete
execute if score #snake2 snakes matches 56 run fill -174 -49 117 -173 -49 117 minecraft:lime_concrete
execute if score #snake2 snakes matches 56 run setblock -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 56 run setblock -171 -49 117 minecraft:air

#Snake fill score 60
execute if score #snake2 snakes matches 61 run fill -173 -49 117 -172 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 61 run fill -174 -49 117 -174 -49 118 minecraft:lime_concrete
execute if score #snake2 snakes matches 61 run fill -174 -49 119 -175 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 61 run fill -176 -49 119 -176 -49 120 minecraft:lime_concrete
execute if score #snake2 snakes matches 61 run fill -176 -49 121 -175 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 61 run fill -174 -49 121 -174 -48 121 minecraft:lime_concrete

#Snake fill score 65
execute if score #snake2 snakes matches 66 run setblock -172 -49 117 minecraft:air
execute if score #snake2 snakes matches 66 run fill -173 -49 117 -174 -49 117 minecraft:green_concrete
execute if score #snake2 snakes matches 66 run fill -174 -49 118 -174 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 66 run fill -175 -49 119 -176 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 66 run fill -176 -49 120 -176 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 66 run fill -175 -49 121 -174 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 66 run fill -174 -48 121 -174 -48 122 minecraft:lime_concrete

#Snake fill score 70
execute if score #snake2 snakes matches 71 run setblock -173 -49 117 minecraft:air
execute if score #snake2 snakes matches 71 run fill -174 -49 117 -174 -49 118 minecraft:green_concrete
execute if score #snake2 snakes matches 71 run fill -174 -49 119 -175 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 71 run fill -176 -49 119 -176 -49 120 minecraft:green_concrete
execute if score #snake2 snakes matches 71 run fill -176 -49 121 -175 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 71 run fill -174 -49 121 -174 -48 121 minecraft:green_concrete
execute if score #snake2 snakes matches 71 run fill -174 -48 122 -174 -48 123 minecraft:lime_concrete

#Snake fill score 75
execute if score #snake2 snakes matches 76 run setblock -174 -49 117 minecraft:air
execute if score #snake2 snakes matches 76 run fill -174 -49 118 -174 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 76 run fill -175 -49 119 -176 -49 119 minecraft:lime_concrete
execute if score #snake2 snakes matches 76 run fill -176 -49 120 -176 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 76 run fill -175 -49 121 -174 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 76 run fill -174 -48 121 -174 -48 122 minecraft:green_concrete
execute if score #snake2 snakes matches 76 run fill -174 -48 123 -174 -48 124 minecraft:lime_concrete

#Snake fill score 80
execute if score #snake2 snakes matches 81 run setblock -174 -49 118 minecraft:air
execute if score #snake2 snakes matches 81 run fill -174 -49 119 -175 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 81 run fill -176 -49 119 -176 -49 120 minecraft:lime_concrete
execute if score #snake2 snakes matches 81 run fill -176 -49 121 -175 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 81 run fill -174 -49 121 -174 -48 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 81 run fill -174 -48 122 -174 -48 123 minecraft:green_concrete
execute if score #snake2 snakes matches 81 run fill -174 -48 124 -174 -47 124 minecraft:lime_concrete

#Snake fill score 85
execute if score #snake2 snakes matches 86 run setblock -174 -49 119 minecraft:air
execute if score #snake2 snakes matches 86 run fill -175 -49 119 -176 -49 119 minecraft:green_concrete
execute if score #snake2 snakes matches 86 run fill -176 -49 120 -176 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 86 run fill -175 -49 121 -174 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 86 run fill -174 -48 121 -174 -48 122 minecraft:lime_concrete
execute if score #snake2 snakes matches 86 run fill -174 -48 123 -174 -48 124 minecraft:green_concrete
execute if score #snake2 snakes matches 86 run fill -174 -47 124 -173 -47 124 minecraft:lime_concrete

#Snake fill score 90
execute if score #snake2 snakes matches 91 run setblock -175 -49 119 minecraft:air
execute if score #snake2 snakes matches 91 run fill -176 -49 119 -176 -49 120 minecraft:green_concrete
execute if score #snake2 snakes matches 91 run fill -176 -49 121 -175 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 91 run fill -174 -49 121 -174 -48 121 minecraft:green_concrete
execute if score #snake2 snakes matches 91 run fill -174 -48 122 -174 -48 123 minecraft:lime_concrete
execute if score #snake2 snakes matches 91 run fill -174 -48 124 -174 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 91 run fill -173 -47 124 -172 -47 124 minecraft:lime_concrete

#Snake fill score 95
execute if score #snake2 snakes matches 96 run setblock -176 -49 119 minecraft:air
execute if score #snake2 snakes matches 96 run fill -176 -49 120 -176 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 96 run fill -175 -49 121 -174 -49 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 96 run fill -174 -48 121 -174 -48 122 minecraft:green_concrete
execute if score #snake2 snakes matches 96 run fill -174 -48 123 -174 -48 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 96 run fill -174 -47 124 -173 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 96 run fill -172 -47 124 -172 -47 125 minecraft:lime_concrete

#Snake fill score 100
execute if score #snake2 snakes matches 101 run setblock -176 -49 120 minecraft:air
execute if score #snake2 snakes matches 101 run fill -176 -49 121 -175 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 101 run fill -174 -49 121 -174 -48 121 minecraft:lime_concrete
execute if score #snake2 snakes matches 101 run fill -174 -48 122 -174 -48 123 minecraft:green_concrete
execute if score #snake2 snakes matches 101 run fill -174 -48 124 -174 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 101 run fill -173 -47 124 -172 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 101 run fill -172 -47 125 -172 -46 125 minecraft:lime_concrete

#Snake fill score 105
execute if score #snake2 snakes matches 106 run setblock -176 -49 121 minecraft:air
execute if score #snake2 snakes matches 106 run fill -174 -49 121 -175 -49 121 minecraft:green_concrete
execute if score #snake2 snakes matches 106 run fill -174 -48 121 -174 -48 122 minecraft:lime_concrete
execute if score #snake2 snakes matches 106 run fill -174 -48 123 -174 -48 124 minecraft:green_concrete
execute if score #snake2 snakes matches 106 run fill -174 -47 124 -173 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 106 run fill -172 -47 124 -172 -47 125 minecraft:green_concrete
execute if score #snake2 snakes matches 106 run fill -172 -46 125 -171 -46 125 minecraft:lime_concrete

#Snake fill score 110
execute if score #snake2 snakes matches 111 run setblock -175 -49 121 minecraft:air
execute if score #snake2 snakes matches 111 run fill -174 -49 121 -174 -48 121 minecraft:green_concrete
execute if score #snake2 snakes matches 111 run fill -174 -48 122 -174 -48 123 minecraft:lime_concrete
execute if score #snake2 snakes matches 111 run fill -174 -48 124 -174 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 111 run fill -173 -47 124 -172 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 111 run fill -172 -47 125 -172 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 111 run fill -171 -46 125 -170 -46 125 minecraft:lime_concrete

#Snake fill score 115
execute if score #snake2 snakes matches 116 run setblock -174 -49 121 minecraft:air
execute if score #snake2 snakes matches 116 run fill -174 -48 121 -174 -48 122 minecraft:green_concrete
execute if score #snake2 snakes matches 116 run fill -174 -48 123 -174 -48 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 116 run fill -174 -47 124 -173 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 116 run fill -172 -47 124 -172 -47 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 116 run fill -172 -46 125 -171 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 116 run fill -170 -46 125 -170 -45 125 minecraft:lime_concrete

#Snake fill score 120
execute if score #snake2 snakes matches 121 run setblock -174 -48 121 minecraft:air
execute if score #snake2 snakes matches 121 run fill -174 -48 122 -174 -48 123 minecraft:green_concrete
execute if score #snake2 snakes matches 121 run fill -174 -48 124 -174 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 121 run fill -173 -47 124 -172 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 121 run fill -172 -47 125 -172 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 121 run fill -171 -46 125 -170 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 121 run fill -170 -45 125 -169 -45 125 minecraft:lime_concrete

#Snake fill score 125
execute if score #snake2 snakes matches 126 run setblock -174 -48 122 minecraft:air
execute if score #snake2 snakes matches 126 run fill -174 -48 123 -174 -48 124 minecraft:green_concrete
execute if score #snake2 snakes matches 126 run fill -174 -47 124 -173 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 126 run fill -172 -47 124 -172 -47 125 minecraft:green_concrete
execute if score #snake2 snakes matches 126 run fill -172 -46 125 -171 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 126 run fill -170 -46 125 -170 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 126 run fill -169 -45 125 -168 -45 125 minecraft:lime_concrete

#Snake fill score 130
execute if score #snake2 snakes matches 131 run setblock -174 -48 123 minecraft:air
execute if score #snake2 snakes matches 131 run fill -174 -48 124 -174 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 131 run fill -173 -47 124 -172 -47 124 minecraft:lime_concrete
execute if score #snake2 snakes matches 131 run fill -172 -47 125 -172 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 131 run fill -171 -46 125 -170 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 131 run fill -170 -45 125 -169 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 131 run fill -168 -45 125 -168 -45 126 minecraft:lime_concrete

#Snake fill score 135
execute if score #snake2 snakes matches 136 run setblock -174 -48 124 minecraft:air
execute if score #snake2 snakes matches 136 run fill -174 -47 124 -173 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 136 run fill -172 -47 124 -172 -47 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 136 run fill -172 -46 125 -171 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 136 run fill -170 -46 125 -170 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 136 run fill -169 -45 125 -168 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 136 run fill -168 -45 126 -168 -45 127 minecraft:lime_concrete

#Snake fill score 140
execute if score #snake2 snakes matches 141 run setblock -174 -47 124 minecraft:air
execute if score #snake2 snakes matches 141 run fill -173 -47 124 -172 -47 124 minecraft:green_concrete
execute if score #snake2 snakes matches 141 run fill -172 -47 125 -172 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 141 run fill -171 -46 125 -170 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 141 run fill -170 -45 125 -169 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 141 run fill -168 -45 125 -168 -45 126 minecraft:green_concrete
execute if score #snake2 snakes matches 141 run fill -168 -45 127 -168 -45 128 minecraft:lime_concrete

#Snake fill score 145
execute if score #snake2 snakes matches 146 run setblock -173 -47 124 minecraft:air
execute if score #snake2 snakes matches 146 run fill -172 -47 124 -172 -47 125 minecraft:green_concrete
execute if score #snake2 snakes matches 146 run fill -172 -46 125 -171 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 146 run fill -170 -46 125 -170 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 146 run fill -169 -45 125 -168 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 146 run fill -168 -45 126 -168 -45 127 minecraft:green_concrete
execute if score #snake2 snakes matches 146 run fill -168 -45 128 -169 -45 128 minecraft:lime_concrete

#Snake fill score 150
execute if score #snake2 snakes matches 151 run setblock -172 -47 124 minecraft:air
execute if score #snake2 snakes matches 151 run fill -172 -47 125 -172 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 151 run fill -171 -46 125 -170 -46 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 151 run fill -170 -45 125 -169 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 151 run fill -168 -45 125 -168 -45 126 minecraft:lime_concrete
execute if score #snake2 snakes matches 151 run fill -168 -45 127 -168 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 151 run fill -169 -45 128 -170 -45 128 minecraft:lime_concrete

#Snake fill score 155
execute if score #snake2 snakes matches 156 run setblock -172 -47 125 minecraft:air
execute if score #snake2 snakes matches 156 run fill -172 -46 125 -171 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 156 run fill -170 -46 125 -170 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 156 run fill -169 -45 125 -168 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 156 run fill -168 -45 126 -168 -45 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 156 run fill -168 -45 128 -169 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 156 run fill -170 -45 128 -170 -44 128 minecraft:lime_concrete

#Snake fill score 160
execute if score #snake2 snakes matches 161 run setblock -172 -46 125 minecraft:air
execute if score #snake2 snakes matches 161 run fill -170 -46 125 -171 -46 125 minecraft:green_concrete
execute if score #snake2 snakes matches 161 run fill -170 -45 125 -169 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 161 run fill -168 -45 125 -168 -45 126 minecraft:green_concrete
execute if score #snake2 snakes matches 161 run fill -168 -45 127 -168 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 161 run fill -169 -45 128 -170 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 161 run fill -170 -44 128 -170 -44 127 minecraft:lime_concrete

#Snake fill score 165
execute if score #snake2 snakes matches 166 run setblock -171 -46 125 minecraft:air
execute if score #snake2 snakes matches 166 run fill -170 -46 125 -170 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 166 run fill -169 -45 125 -168 -45 125 minecraft:lime_concrete
execute if score #snake2 snakes matches 166 run fill -168 -45 126 -168 -45 127 minecraft:green_concrete
execute if score #snake2 snakes matches 166 run fill -168 -45 128 -169 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 166 run fill -170 -45 128 -170 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 166 run fill -170 -44 127 -170 -43 127 minecraft:lime_concrete

#Snake fill score 170
execute if score #snake2 snakes matches 171 run setblock -170 -46 125 minecraft:air
execute if score #snake2 snakes matches 171 run fill -170 -45 125 -169 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 171 run fill -168 -45 125 -168 -45 126 minecraft:lime_concrete
execute if score #snake2 snakes matches 171 run fill -168 -45 127 -168 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 171 run fill -169 -45 128 -170 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 171 run fill -170 -44 128 -170 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 171 run fill -170 -43 127 -171 -43 127 minecraft:lime_concrete

#Snake fill score 175
execute if score #snake2 snakes matches 176 run setblock -170 -45 125 minecraft:air
execute if score #snake2 snakes matches 176 run fill -169 -45 125 -168 -45 125 minecraft:green_concrete
execute if score #snake2 snakes matches 176 run fill -168 -45 126 -168 -45 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 176 run fill -168 -45 128 -169 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 176 run fill -170 -45 128 -170 -44 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 176 run fill -170 -44 127 -170 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 176 run fill -171 -43 127 -172 -43 127 minecraft:lime_concrete

#Snake fill score 180
execute if score #snake2 snakes matches 181 run setblock -169 -45 125 minecraft:air
execute if score #snake2 snakes matches 181 run fill -168 -45 125 -168 -45 126 minecraft:green_concrete
execute if score #snake2 snakes matches 181 run fill -168 -45 127 -168 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 181 run fill -169 -45 128 -170 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 181 run fill -170 -44 128 -170 -44 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 181 run fill -170 -43 127 -171 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 181 run fill -172 -43 127 -173 -43 127 minecraft:lime_concrete

#Snake fill score 185
execute if score #snake2 snakes matches 186 run setblock -168 -45 125 minecraft:air
execute if score #snake2 snakes matches 186 run fill -168 -45 126 -168 -45 127 minecraft:green_concrete
execute if score #snake2 snakes matches 186 run fill -168 -45 128 -169 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 186 run fill -170 -45 128 -170 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 186 run fill -170 -44 127 -170 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 186 run fill -171 -43 127 -172 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 186 run fill -173 -43 127 -174 -43 127 minecraft:lime_concrete

#Snake fill score 190
execute if score #snake2 snakes matches 191 run setblock -168 -45 126 minecraft:air
execute if score #snake2 snakes matches 191 run fill -168 -45 127 -168 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 191 run fill -169 -45 128 -170 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 191 run fill -170 -44 128 -170 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 191 run fill -170 -43 127 -171 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 191 run fill -172 -43 127 -173 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 191 run fill -174 -43 127 -174 -44 127 minecraft:lime_concrete

#Snake fill score 195
execute if score #snake2 snakes matches 196 run setblock -168 -45 127 minecraft:air
execute if score #snake2 snakes matches 196 run fill -168 -45 128 -169 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 196 run fill -170 -44 128 -170 -45 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 196 run fill -170 -44 127 -170 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 196 run fill -171 -43 127 -172 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 196 run fill -173 -43 127 -174 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 196 run fill -174 -44 127 -174 -44 128 minecraft:lime_concrete

#Snake fill score 200
execute if score #snake2 snakes matches 201 run setblock -168 -45 128 minecraft:air
execute if score #snake2 snakes matches 201 run fill -169 -45 128 -170 -45 128 minecraft:green_concrete
execute if score #snake2 snakes matches 201 run fill -170 -44 128 -170 -44 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 201 run fill -170 -43 127 -171 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 201 run fill -172 -43 127 -173 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 201 run fill -174 -43 127 -174 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 201 run fill -174 -44 128 -174 -44 129 minecraft:lime_concrete

#Snake fill score 205
execute if score #snake2 snakes matches 206 run setblock -169 -45 128 minecraft:air
execute if score #snake2 snakes matches 206 run fill -170 -45 128 -170 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 206 run fill -170 -44 127 -170 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 206 run fill -171 -43 127 -172 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 206 run fill -173 -43 127 -174 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 206 run fill -174 -44 127 -174 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 206 run fill -174 -44 129 -175 -44 129 minecraft:lime_concrete

#Snake fill score 210
execute if score #snake2 snakes matches 211 run setblock -170 -45 128 minecraft:air
execute if score #snake2 snakes matches 211 run fill -170 -44 128 -170 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 211 run fill -170 -43 127 -171 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 211 run fill -172 -43 127 -173 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 211 run fill -174 -43 127 -174 -44 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 211 run fill -174 -44 128 -174 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 211 run fill -175 -44 129 -176 -44 129 minecraft:lime_concrete

#Snake fill score 215
execute if score #snake2 snakes matches 216 run setblock -170 -44 128 minecraft:air
execute if score #snake2 snakes matches 216 run fill -170 -44 127 -170 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 216 run fill -171 -43 127 -172 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 216 run fill -173 -43 127 -174 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 216 run fill -174 -44 127 -174 -44 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 216 run fill -174 -44 129 -175 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 216 run fill -176 -44 129 -177 -44 129 minecraft:lime_concrete

#Snake fill score 220
execute if score #snake2 snakes matches 221 run setblock -170 -44 127 minecraft:air
execute if score #snake2 snakes matches 221 run fill -170 -43 127 -171 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 221 run fill -172 -43 127 -173 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 221 run fill -174 -43 127 -174 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 221 run fill -174 -44 128 -174 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 221 run fill -175 -44 129 -176 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 221 run fill -177 -44 129 -178 -44 129 minecraft:lime_concrete

#Snake fill score 225
execute if score #snake2 snakes matches 226 run setblock -170 -43 127 minecraft:air
execute if score #snake2 snakes matches 226 run fill -171 -43 127 -172 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 226 run fill -173 -43 127 -174 -43 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 226 run fill -174 -44 127 -174 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 226 run fill -174 -44 129 -175 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 226 run fill -176 -44 129 -177 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 226 run fill -178 -44 129 -179 -44 129 minecraft:lime_concrete

execute if score #snake2 snakes matches 226 run setblock -180 -44 129 minecraft:green_concrete

#Snake fill score 230
execute if score #snake2 snakes matches 231 run setblock -171 -43 127 minecraft:air
execute if score #snake2 snakes matches 231 run fill -172 -43 127 -173 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 231 run fill -174 -43 127 -174 -44 127 minecraft:lime_concrete
execute if score #snake2 snakes matches 231 run fill -174 -44 128 -174 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 231 run fill -175 -44 129 -176 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 231 run fill -177 -44 129 -178 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 231 run setblock -179 -44 129 minecraft:lime_concrete


#Snake fill score 235
execute if score #snake2 snakes matches 236 run setblock -172 -43 127 minecraft:air
execute if score #snake2 snakes matches 236 run fill -173 -43 127 -174 -43 127 minecraft:green_concrete
execute if score #snake2 snakes matches 236 run fill -174 -44 127 -174 -44 128 minecraft:lime_concrete
execute if score #snake2 snakes matches 236 run fill -174 -44 129 -175 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 236 run fill -176 -44 129 -177 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 236 run fill -178 -44 129 -179 -44 129 minecraft:green_concrete

#Snake fill score 240
execute if score #snake2 snakes matches 241 run setblock -173 -43 127 minecraft:air
execute if score #snake2 snakes matches 241 run fill -174 -43 127 -174 -44 127 minecraft:green_concrete
execute if score #snake2 snakes matches 241 run fill -174 -44 128 -174 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 241 run fill -175 -44 129 -176 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 241 run fill -177 -44 129 -178 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 241 run setblock -179 -44 129 minecraft:green_concrete

#Snake fill score 245
execute if score #snake2 snakes matches 246 run setblock -174 -43 127 minecraft:air
execute if score #snake2 snakes matches 246 run fill -174 -44 127 -174 -44 128 minecraft:green_concrete
execute if score #snake2 snakes matches 246 run fill -174 -44 129 -175 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 246 run fill -176 -44 129 -177 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 246 run fill -178 -44 129 -179 -44 129 minecraft:lime_concrete

#Snake fill score 250
execute if score #snake2 snakes matches 251 run setblock -174 -44 127 minecraft:air
execute if score #snake2 snakes matches 251 run fill -174 -44 128 -174 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 251 run fill -175 -44 129 -176 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 251 run fill -177 -44 129 -178 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 251 run setblock -179 -44 129 minecraft:lime_concrete

#Snake fill score 255
execute if score #snake2 snakes matches 256 run setblock -174 -44 128 minecraft:air
execute if score #snake2 snakes matches 256 run fill -174 -44 129 -175 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 256 run fill -176 -44 129 -177 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 256 run fill -178 -44 129 -179 -44 129 minecraft:green_concrete

#Snake fill score 260
execute if score #snake2 snakes matches 261 run setblock -179 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 261 run fill -178 -44 129 -177 -44 129 minecraft:lime_concrete
execute if score #snake2 snakes matches 261 run fill -176 -44 129 -175 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 261 run setblock -174 -44 129 minecraft:air

#Snake fill score 265
execute if score #snake2 snakes matches 266 run setblock -175 -44 129 minecraft:air
execute if score #snake2 snakes matches 266 run fill -176 -44 129 -177 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 266 run fill -178 -44 129 -179 -44 129 minecraft:lime_concrete

#Snake fill score 270
execute if score #snake2 snakes matches 271 run setblock -176 -44 129 minecraft:air
execute if score #snake2 snakes matches 271 run fill -177 -44 129 -178 -44 129 minecraft:green_concrete
execute if score #snake2 snakes matches 271 run setblock -179 -44 129 minecraft:lime_concrete

#Snake fill score 275
execute if score #snake2 snakes matches 276 run setblock -177 -44 129 minecraft:air
execute if score #snake2 snakes matches 276 run setblock -179 -44 129 minecraft:green_concrete

#Snake fill score 280
execute if score #snake2 snakes matches 281 run setblock -178 -44 129 minecraft:air

#Snake fill score 285
execute if score #snake2 snakes matches 286 run setblock -179 -44 129 minecraft:air

#Snake fill score 290
execute if score #snake2 snakes matches 291 run setblock -180 -44 129 minecraft:air

#end snake
execute if score #snake2 snakes matches 291.. run setblock -170 -47 117 minecraft:jungle_pressure_plate
execute if score #snake2 snakes matches 291.. run kill @e[type=marker,name=snake2]
execute if score #snake2 snakes matches 291.. run scoreboard players reset #snake2 snakes