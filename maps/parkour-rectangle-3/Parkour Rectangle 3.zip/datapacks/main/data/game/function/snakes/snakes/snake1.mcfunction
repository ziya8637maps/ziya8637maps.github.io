execute if entity @e[type=marker,name=snake1] run scoreboard players add #snake1 snakes 1

#snake fill score 0
execute if score #snake1 snakes matches 1 run setblock -70 -24 132 minecraft:yellow_concrete

#snake fill score 5
execute if score #snake1 snakes matches 6 run fill -70 -24 132 -71 -24 132 minecraft:yellow_concrete

#snake fill score 10
execute if score #snake1 snakes matches 11 run fill -72 -24 132 -71 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 11 run setblock -70 -24 132 minecraft:orange_concrete

#snake fill score 15
execute if score #snake1 snakes matches 16 run fill -71 -24 132 -70 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 16 run fill -73 -24 132 -72 -24 132 minecraft:yellow_concrete

#snake fill score 20
execute if score #snake1 snakes matches 21 run fill -74 -24 132 -73 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 21 run fill -72 -24 132 -71 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 21 run setblock -70 -24 132 minecraft:yellow_concrete

#snake fill score 25
execute if score #snake1 snakes matches 26 run fill -71 -24 132 -70 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 26 run fill -73 -24 132 -72 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 26 run fill -74 -24 132 -74 -24 131 minecraft:yellow_concrete

#snake fill score 30
execute if score #snake1 snakes matches 31 run fill -74 -24 130 -74 -24 131 minecraft:yellow_concrete
execute if score #snake1 snakes matches 31 run fill -74 -24 132 -73 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 31 run fill -72 -24 132 -71 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 31 run setblock -70 -24 132 minecraft:orange_concrete

#snake fill score 35
execute if score #snake1 snakes matches 36 run fill -74 -24 130 -74 -23 130 minecraft:yellow_concrete
execute if score #snake1 snakes matches 36 run fill -74 -24 131 -74 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 36 run fill -73 -24 132 -72 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 36 run fill -71 -24 132 -70 -24 132 minecraft:orange_concrete

#snake fill score 40
execute if score #snake1 snakes matches 41 run fill -74 -23 129 -74 -23 130 minecraft:yellow_concrete
execute if score #snake1 snakes matches 41 run fill -74 -24 130 -74 -24 131 minecraft:orange_concrete
execute if score #snake1 snakes matches 41 run fill -74 -24 132 -73 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 41 run fill -72 -24 132 -71 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 41 run setblock -70 -24 132 minecraft:yellow_concrete

#snake fill score 45
execute if score #snake1 snakes matches 46 run fill -74 -23 128 -74 -23 129 minecraft:yellow_concrete
execute if score #snake1 snakes matches 46 run fill -74 -23 130 -74 -24 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 46 run fill -74 -24 131 -74 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 46 run fill -73 -24 132 -72 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 46 run fill -71 -24 132 -70 -24 132 minecraft:yellow_concrete

#snake fill score 50
execute if score #snake1 snakes matches 51 run fill -75 -23 128 -74 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 51 run fill -74 -23 129 -74 -23 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 51 run fill -74 -24 130 -74 -24 131 minecraft:yellow_concrete
execute if score #snake1 snakes matches 51 run fill -74 -24 132 -73 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 51 run fill -72 -24 132 -71 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 51 run setblock -70 -24 132 minecraft:orange_concrete

#snake fill score 55
execute if score #snake1 snakes matches 56 run fill -70 -24 132 -71 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 56 run fill -72 -24 132 -73 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 56 run fill -74 -24 132 -74 -24 131 minecraft:orange_concrete
execute if score #snake1 snakes matches 56 run fill -74 -24 130 -74 -23 130 minecraft:yellow_concrete
execute if score #snake1 snakes matches 56 run fill -74 -23 129 -74 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 56 run fill -75 -23 128 -76 -23 128 minecraft:yellow_concrete

#snake fill score 60
execute if score #snake1 snakes matches 61 run setblock -70 -24 132 air
execute if score #snake1 snakes matches 61 run fill -71 -24 132 -72 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 61 run fill -73 -24 132 -74 -24 132 minecraft:yellow_concrete
execute if score #snake1 snakes matches 61 run fill -74 -24 131 -74 -24 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 61 run fill -74 -23 130 -74 -23 129 minecraft:yellow_concrete
execute if score #snake1 snakes matches 61 run fill -74 -23 128 -75 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 61 run fill -76 -23 128 -76 -22 128 minecraft:yellow_concrete

#snake fill score 65
execute if score #snake1 snakes matches 66 run setblock -71 -24 132 minecraft:air
execute if score #snake1 snakes matches 66 run fill -72 -24 132 -73 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 66 run fill -74 -24 132 -74 -24 131 minecraft:yellow_concrete
execute if score #snake1 snakes matches 66 run fill -74 -24 130 -74 -23 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 66 run fill -74 -23 129 -74 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 66 run fill -75 -23 128 -76 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 66 run fill -76 -22 128 -76 -22 127 minecraft:yellow_concrete

#snake fill score 70
execute if score #snake1 snakes matches 71 run setblock -72 -24 132 minecraft:air
execute if score #snake1 snakes matches 71 run fill -73 -24 132 -74 -24 132 minecraft:orange_concrete
execute if score #snake1 snakes matches 71 run fill -74 -24 131 -74 -24 130 minecraft:yellow_concrete
execute if score #snake1 snakes matches 71 run fill -74 -23 130 -74 -23 129 minecraft:orange_concrete
execute if score #snake1 snakes matches 71 run fill -74 -23 128 -75 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 71 run fill -76 -23 128 -76 -22 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 71 run fill -76 -22 127 -76 -22 126 minecraft:yellow_concrete

#snake fill score 75
execute if score #snake1 snakes matches 75 run setblock -73 -24 132 minecraft:air
execute if score #snake1 snakes matches 75 run fill -74 -24 132 -74 -24 131 minecraft:orange_concrete
execute if score #snake1 snakes matches 75 run fill -74 -24 130 -74 -23 130 minecraft:yellow_concrete
execute if score #snake1 snakes matches 75 run fill -74 -23 129 -74 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 75 run fill -75 -23 128 -76 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 75 run fill -76 -22 128 -76 -22 127 minecraft:orange_concrete
execute if score #snake1 snakes matches 75 run fill -76 -22 126 -76 -21 126 minecraft:yellow_concrete

#snake fill score 80
execute if score #snake1 snakes matches 81 run setblock -74 -24 132 minecraft:air
execute if score #snake1 snakes matches 81 run fill -74 -24 131 -74 -24 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 81 run fill -74 -23 130 -74 -23 129 minecraft:yellow_concrete
execute if score #snake1 snakes matches 81 run fill -74 -23 128 -75 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 81 run fill -76 -23 128 -76 -22 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 81 run fill -76 -22 127 -76 -22 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 81 run fill -76 -21 126 -75 -21 126 minecraft:yellow_concrete

#snake fill score 85
execute if score #snake1 snakes matches 86 run setblock -74 -24 131 minecraft:air
execute if score #snake1 snakes matches 86 run fill -74 -24 130 -74 -23 130 minecraft:orange_concrete
execute if score #snake1 snakes matches 86 run fill -74 -23 129 -74 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 86 run fill -75 -23 128 -76 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 86 run fill -76 -22 128 -76 -22 127 minecraft:yellow_concrete
execute if score #snake1 snakes matches 86 run fill -76 -22 126 -76 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 86 run fill -75 -21 126 -74 -21 126 minecraft:yellow_concrete

#snake fill score 90
execute if score #snake1 snakes matches 91 run setblock -74 -24 130 minecraft:air
execute if score #snake1 snakes matches 91 run fill -74 -21 125 -74 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 91 run fill -75 -21 126 -76 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 91 run fill -76 -22 126 -76 -22 127 minecraft:yellow_concrete
execute if score #snake1 snakes matches 91 run fill -76 -22 128 -76 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 91 run fill -75 -23 128 -74 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 91 run fill -74 -23 129 -74 -23 130 minecraft:orange_concrete

#snake fill score 95
execute if score #snake1 snakes matches 96 run setblock -74 -23 130 minecraft:air
execute if score #snake1 snakes matches 96 run fill -74 -23 129 -74 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 96 run fill -75 -23 128 -76 -23 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 96 run fill -76 -22 128 -76 -22 127 minecraft:orange_concrete
execute if score #snake1 snakes matches 96 run fill -76 -22 126 -76 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 96 run fill -75 -21 126 -74 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 96 run fill -74 -21 125 -74 -20 125 minecraft:yellow_concrete

#snake fill score 100
execute if score #snake1 snakes matches 101 run setblock -74 -23 129 minecraft:air
execute if score #snake1 snakes matches 101 run fill -74 -23 128 -75 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 101 run fill -76 -23 128 -76 -22 128 minecraft:yellow_concrete
execute if score #snake1 snakes matches 101 run fill -76 -22 127 -76 -22 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 101 run fill -76 -21 126 -75 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 101 run fill -74 -21 126 -74 -21 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 101 run fill -74 -20 125 -74 -20 124 minecraft:yellow_concrete

#snake fill score 105
execute if score #snake1 snakes matches 106 run setblock -74 -23 128 minecraft:air
execute if score #snake1 snakes matches 106 run fill -75 -23 128 -76 -23 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 106 run fill -76 -22 128 -76 -22 127 minecraft:yellow_concrete
execute if score #snake1 snakes matches 106 run fill -76 -22 126 -76 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 106 run fill -75 -21 126 -74 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 106 run fill -74 -21 125 -74 -20 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 106 run fill -74 -20 124 -75 -20 124 minecraft:yellow_concrete

#snake fill score 110
execute if score #snake1 snakes matches 111 run setblock -75 -23 128 minecraft:air
execute if score #snake1 snakes matches 111 run fill -76 -23 128 -76 -22 128 minecraft:orange_concrete
execute if score #snake1 snakes matches 111 run fill -76 -22 127 -76 -22 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 111 run fill -76 -21 126 -75 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 111 run fill -74 -21 126 -74 -21 125 minecraft:yellow_concrete
execute if score #snake1 snakes matches 111 run fill -74 -20 125 -74 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 111 run fill -75 -20 124 -76 -20 124 minecraft:yellow_concrete

#snake fill score 115
execute if score #snake1 snakes matches 116 run setblock -76 -23 128 minecraft:air
execute if score #snake1 snakes matches 116 run fill -76 -22 128 -76 -22 127 minecraft:orange_concrete
execute if score #snake1 snakes matches 116 run fill -76 -22 126 -76 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 116 run fill -75 -21 126 -74 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 116 run fill -74 -21 125 -74 -20 125 minecraft:yellow_concrete
execute if score #snake1 snakes matches 116 run fill -74 -20 124 -75 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 116 run fill -76 -20 124 -76 -19 124 minecraft:yellow_concrete

#snake fill score 120
execute if score #snake1 snakes matches 121 run setblock -76 -22 128 minecraft:air
execute if score #snake1 snakes matches 121 run fill -76 -22 127 -76 -22 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 121 run fill -76 -21 126 -75 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 121 run fill -74 -21 126 -74 -21 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 121 run fill -74 -20 125 -74 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 121 run fill -75 -20 124 -76 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 121 run fill -76 -19 124 -76 -19 123 minecraft:yellow_concrete

#snake fill score 125
execute if score #snake1 snakes matches 126 run setblock -76 -22 127 minecraft:air
execute if score #snake1 snakes matches 126 run fill -76 -22 126 -76 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 126 run fill -75 -21 126 -74 -21 126 minecraft:yellow_concrete
execute if score #snake1 snakes matches 126 run fill -74 -21 125 -74 -20 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 126 run fill -74 -20 124 -75 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 126 run fill -76 -20 124 -76 -19 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 126 run fill -76 -19 123 -76 -19 122 minecraft:yellow_concrete

#snake fill score 130
execute if score #snake1 snakes matches 131 run setblock -76 -22 126 minecraft:air
execute if score #snake1 snakes matches 131 run fill -76 -21 126 -75 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 131 run fill -74 -21 126 -74 -21 125 minecraft:yellow_concrete
execute if score #snake1 snakes matches 131 run fill -74 -20 125 -74 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 131 run fill -75 -20 124 -76 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 131 run fill -76 -19 124 -76 -19 123 minecraft:orange_concrete
execute if score #snake1 snakes matches 131 run fill -76 -19 122 -76 -19 121 minecraft:yellow_concrete

#snake fill score 135
execute if score #snake1 snakes matches 136 run setblock -76 -21 126 minecraft:air
execute if score #snake1 snakes matches 136 run fill -75 -21 126 -74 -21 126 minecraft:orange_concrete
execute if score #snake1 snakes matches 136 run fill -74 -21 125 -74 -20 125 minecraft:yellow_concrete
execute if score #snake1 snakes matches 136 run fill -74 -20 124 -75 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 136 run fill -76 -20 124 -76 -19 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 136 run fill -76 -19 123 -76 -19 122 minecraft:orange_concrete
execute if score #snake1 snakes matches 136 run fill -76 -19 121 -76 -19 120 minecraft:yellow_concrete

#exit snake
#snake fill score 140
execute if score #snake1 snakes matches 141 run setblock -75 -21 126 minecraft:air
execute if score #snake1 snakes matches 141 run fill -74 -21 126 -74 -21 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 141 run fill -74 -20 125 -74 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 141 run fill -75 -20 124 -76 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 141 run fill -76 -19 124 -76 -19 123 minecraft:yellow_concrete
execute if score #snake1 snakes matches 141 run fill -76 -19 122 -76 -19 121 minecraft:orange_concrete
execute if score #snake1 snakes matches 141 run setblock -76 -19 120 minecraft:yellow_concrete

#snake fill score 145
execute if score #snake1 snakes matches 146 run setblock -74 -21 126 minecraft:air
execute if score #snake1 snakes matches 146 run fill -74 -21 125 -74 -20 125 minecraft:orange_concrete
execute if score #snake1 snakes matches 146 run fill -74 -20 124 -75 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 146 run fill -76 -20 124 -76 -19 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 146 run fill -76 -19 123 -76 -19 122 minecraft:yellow_concrete
execute if score #snake1 snakes matches 146 run fill -76 -19 121 -76 -19 120 minecraft:orange_concrete

#snake fill score 150
execute if score #snake1 snakes matches 151 run setblock -74 -21 125 minecraft:air
execute if score #snake1 snakes matches 151 run fill -74 -20 125 -74 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 151 run fill -75 -20 124 -76 -20 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 151 run fill -76 -19 124 -76 -19 123 minecraft:orange_concrete
execute if score #snake1 snakes matches 151 run fill -76 -19 122 -76 -19 121 minecraft:yellow_concrete
execute if score #snake1 snakes matches 151 run setblock -76 -19 120 minecraft:orange_concrete

#snake fill score 155
execute if score #snake1 snakes matches 156 run setblock -74 -20 125 minecraft:air
execute if score #snake1 snakes matches 156 run fill -74 -20 124 -75 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 156 run fill -76 -20 124 -76 -19 124 minecraft:yellow_concrete
execute if score #snake1 snakes matches 156 run fill -76 -19 123 -76 -19 122 minecraft:orange_concrete
execute if score #snake1 snakes matches 156 run fill -76 -19 121 -76 -19 120 minecraft:yellow_concrete

#snake fill score 160
execute if score #snake1 snakes matches 161 run setblock -74 -20 124 minecraft:air
execute if score #snake1 snakes matches 161 run fill -75 -20 124 -76 -20 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 161 run fill -76 -19 124 -76 -19 123 minecraft:yellow_concrete
execute if score #snake1 snakes matches 161 run fill -76 -19 122 -76 -19 121 minecraft:orange_concrete
execute if score #snake1 snakes matches 161 run setblock -76 -19 120 minecraft:yellow_concrete

#snake fill score 165
execute if score #snake1 snakes matches 166 run setblock -75 -20 124 minecraft:air
execute if score #snake1 snakes matches 166 run fill -76 -20 124 -76 -19 124 minecraft:orange_concrete
execute if score #snake1 snakes matches 166 run fill -76 -19 123 -76 -19 122 minecraft:yellow_concrete
execute if score #snake1 snakes matches 166 run fill -76 -19 121 -76 -19 120 minecraft:orange_concrete

#snake fill score 170
execute if score #snake1 snakes matches 171 run setblock -76 -20 124 minecraft:air
execute if score #snake1 snakes matches 171 run fill -76 -19 124 -76 -19 123 minecraft:orange_concrete
execute if score #snake1 snakes matches 171 run fill -76 -19 122 -76 -19 121 minecraft:yellow_concrete
execute if score #snake1 snakes matches 171 run setblock -76 -19 120 minecraft:orange_concrete

#snake fill score 175
execute if score #snake1 snakes matches 176 run setblock -76 -19 124 minecraft:air
execute if score #snake1 snakes matches 176 run fill -76 -19 123 -76 -19 122 minecraft:orange_concrete
execute if score #snake1 snakes matches 176 run fill -76 -19 121 -76 -19 120 minecraft:yellow_concrete

#snake fill score 180
execute if score #snake1 snakes matches 181 run setblock -76 -19 123 minecraft:air
execute if score #snake1 snakes matches 181 run fill -76 -19 122 -76 -19 121 minecraft:orange_concrete
execute if score #snake1 snakes matches 181 run setblock -76 -19 120 minecraft:yellow_concrete

#snake fill score 185
execute if score #snake1 snakes matches 186 run setblock -76 -19 122 minecraft:air
execute if score #snake1 snakes matches 186 run setblock -76 -19 120 minecraft:orange_concrete

#snake fill score 190
execute if score #snake1 snakes matches 191 run setblock -76 -19 121 minecraft:air

#snake fill score 195
execute if score #snake1 snakes matches 196 run setblock -76 -19 120 minecraft:air

#end snake
execute if score #snake1 snakes matches 196.. run setblock -69 -22 132 minecraft:birch_pressure_plate
execute if score #snake1 snakes matches 196.. run kill @e[type=marker,name=snake1]
execute if score #snake1 snakes matches 196.. run scoreboard players reset #snake1 snakes