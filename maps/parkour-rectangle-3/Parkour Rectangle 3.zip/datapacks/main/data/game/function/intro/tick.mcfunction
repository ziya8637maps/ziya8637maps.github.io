scoreboard players add @a[tag=intro] intro 1

execute as @a at @s run function game:intro/intro_title

effect give @a[tag=intro] minecraft:slow_falling 9999 1 true
execute as @a[scores={intro=69..}] at @s run tag @s remove intro
execute as @a[scores={intro=69..}] at @s run effect clear @a slow_falling
execute as @a[scores={intro=69..}] at @s run scoreboard players reset @s intro